import os
os.environ['GACHA_DB']=':memory:'
import copy
import random
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
import bot
from game import Store,GameError,CATALOG
from practice import PracticeBattle

class PracticeTests(unittest.TestCase):
    def setUp(self):self.s=Store(':memory:')
    def tearDown(self):self.s.db.close()
    def grant(self,units):
        self.s.profile(1)
        with self.s.db:
            for unit in units:self.s.db.execute('INSERT OR IGNORE INTO units VALUES(?,?,1)',(1,unit))
        self.s.equip(1,units[0])
        if len(units)==4:self.s.set_lineup(1,units)
    def test_mirror_snapshot_and_no_ai_database_account_or_rewards(self):
        self.grant(['kurumi','mami','aha','rhinedottir'])
        before={table:self.s.db.execute('SELECT * FROM '+table).fetchall() for table in ('players','units','squads','banner_pity','ticket_wallet')}
        b=PracticeBattle(1,self.s,'4v4','hard',random.Random(0))
        self.assertEqual([f.unit for f in b.fighters[:4]],[f.unit for f in b.fighters[4:]])
        while not b.finished:
            if b.fighters[b.turn].uid==b.ai:b.run_ai()
            else:
                action,index=b.choose_ai_move();b.act(1,action,index)
        self.assertEqual(before,{table:self.s.db.execute('SELECT * FROM '+table).fetchall() for table in before})
        self.assertEqual(self.s.db.execute('SELECT count(*) FROM players WHERE id<0').fetchone()[0],0)

    def test_all_characters_and_difficulties_complete_1v1(self):
        for unit in CATALOG:
            for difficulty in ('easy','normal','hard'):
                with self.subTest(unit=unit,difficulty=difficulty):
                    self.grant([unit]);b=PracticeBattle(1,self.s,'1v1',difficulty,random.Random(42))
                    steps=0
                    while not b.finished:
                        if b.fighters[b.turn].uid==b.ai:b.run_ai()
                        else:
                            action,index=b.choose_ai_move();b.act(1,action,index)
                        steps+=1
                        self.assertLessEqual(steps,101)
                        self.assertTrue(all(0<=sp<=5 for sp in b.sp.values()))
                        self.assertTrue(all(0<=f.hp<=f.max_hp for f in b.fighters))
                    self.assertLessEqual(b.rounds,b.limit)

    def test_mixed_4v4_all_difficulties_complete_with_special_actions(self):
        for units in (['ronova','istaroth','rhinedottir','asmoday'],['kurumi','mami','aha','mala'],['kuru','eiji','yuko','mala']):
            self.grant(units)
            for difficulty in ('easy','normal','hard'):
                b=PracticeBattle(1,self.s,'4v4',difficulty,random.Random(5))
                while not b.finished:
                    if b.fighters[b.turn].uid==b.ai:b.run_ai()
                    else:
                        action,index=b.choose_ai_move();b.act(1,action,index)
                self.assertLessEqual(b.rounds,b.limit)
                self.assertTrue(all(0<=value<=5 for value in b.sp.values()))

    def test_invalid_or_incomplete_team_and_modes_rejected(self):
        for mode,difficulty in [('bad','normal'),('1v1','bad')]:
            with self.assertRaises(GameError):PracticeBattle(1,self.s,mode,difficulty)
        with self.assertRaises(GameError):PracticeBattle(1,self.s,'4v4')

    def test_run_ai_stops_at_human_turn_and_never_changes_human_owned_setup(self):
        self.grant(['kuru'])
        b=PracticeBattle(1,self.s,rng=random.Random(0))
        b.run_ai()
        self.assertTrue(b.finished or b.fighters[b.turn].uid==1)
        before=copy.deepcopy((b.sp,b.rounds,[vars(f) for f in b.fighters]))
        self.assertEqual(b.run_ai(),[])
        self.assertEqual(before,(b.sp,b.rounds,[vars(f) for f in b.fighters]))

    def test_aha_mirror_pre_match_settings_equal(self):
        self.grant(['aha','eiji','mala','kurumi']);self.s.set_aha_settings(1,True,True)
        b=PracticeBattle(1,self.s,'4v4',rng=random.Random(0))
        for owner in (1,-1):
            self.assertTrue(b.aha[owner]['global'])
            self.assertEqual(b.aha[owner]['last_snapshot'],20)
            self.assertEqual(b.aha[owner]['instant_count'],1)

class PracticeUITests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.s=Store(':memory:');self.patch=patch.object(bot,'store',self.s);self.patch.start()
        bot.busy.discard(70001)
    def tearDown(self):
        bot.busy.discard(70001);self.patch.stop();self.s.db.close()
    def interaction(self,uid=70001):
        return SimpleNamespace(user=SimpleNamespace(id=uid),response=SimpleNamespace(send_message=AsyncMock(),edit_message=AsyncMock()),original_response=AsyncMock(return_value=SimpleNamespace(edit=AsyncMock())))

    async def test_command_starts_without_acceptance_and_renders_ai_without_fake_mentions(self):
        i=self.interaction();await bot.practice.callback(i)
        kwargs=i.response.send_message.await_args.kwargs;view=kwargs['view']
        self.assertIsInstance(view,bot.PracticeView)
        self.assertNotIn(view.accept,view.children)
        self.assertNotIn(view.cancel,view.children)
        self.assertNotIn('<@-',str(kwargs['embed'].to_dict()))
        self.assertIn('AI',kwargs['embed'].title)
        self.assertIn(70001,bot.busy)
        await view.move(i,'surrender')
        self.assertTrue(view.closed);self.assertNotIn(70001,bot.busy)
        self.assertTrue(all(child.disabled for child in view.children))

    async def test_outsider_cannot_play_and_timeout_frees_busy(self):
        view=bot.PracticeView(70001);bot.busy.add(70001)
        self.assertFalse(await view.interaction_check(self.interaction(70002)))
        before=view.battle.rounds;await view.move(self.interaction(70002),'attack')
        self.assertEqual(before,view.battle.rounds)
        await view.on_timeout()
        self.assertTrue(view.closed);self.assertNotIn(70001,bot.busy)

    async def test_invalid_skill_does_not_give_ai_free_turn(self):
        view=bot.PracticeView(70001);i=self.interaction()
        view.battle.sp[70001]=0
        before=view.battle.rounds;await view.move(i,'skill')
        self.assertEqual(view.battle.rounds,before)
        view.close()

    async def test_failed_start_and_busy_rejection_do_not_leave_stale_lock(self):
        i=self.interaction()
        with self.assertRaises(GameError):await bot.practice.callback(i,bot.app_commands.Choice(name='4v4',value='4v4'))
        self.assertNotIn(70001,bot.busy)
        bot.busy.add(70001)
        with self.assertRaises(GameError):await bot.practice.callback(i)
        bot.busy.discard(70001)
        i.response.send_message.side_effect=RuntimeError('send failed')
        with self.assertRaises(RuntimeError):await bot.practice.callback(i)
        self.assertNotIn(70001,bot.busy)

    async def test_move_and_ai_turn_return_to_human(self):
        view=bot.PracticeView(70001);i=self.interaction()
        await view.move(i,'attack')
        self.assertTrue(view.battle.finished or view.battle.fighters[view.battle.turn].uid==70001)
        self.assertTrue(any('AI' in line for line in view.history))
        self.assertNotIn('<@-',str(view.render().to_dict()))
        view.close()

    async def test_same_interaction_id_does_not_play_twice(self):
        view=bot.PracticeView(70001);i=self.interaction();i.id=123456
        await view.move(i,'attack');before=view.battle.rounds
        await view.move(i,'attack')
        self.assertEqual(view.battle.rounds,before)
        self.assertTrue(i.response.send_message.await_args.kwargs['ephemeral'])
        view.close()

    async def test_message_failure_releases_match(self):
        view=bot.PracticeView(70001);bot.busy.add(70001);i=self.interaction()
        i.response.edit_message.side_effect=RuntimeError('message deleted')
        with self.assertRaises(RuntimeError):await view.move(i,'attack')
        self.assertNotIn(70001,bot.busy);self.assertTrue(view.closed)
