"""Local rule-based AI. No remote service, extra wallets, rewards, or stat boosts."""
import random
from game import Battle,CATALOG,GameError,ULTIMATES
from new_characters import NEW_NAMES,BULLETS

class PracticeBattle(Battle):
    def __init__(self,uid,store,mode='1v1',difficulty='normal',rng=random):
        if mode not in ('1v1','4v4') or difficulty not in ('easy','normal','hard'):
            raise GameError('เลือกโหมด 1v1/4v4 และความยาก easy/normal/hard')
        units=[store.profile(uid)[2]] if mode=='1v1' else store.lineup(uid)
        # Snapshot the player's owned loadout; mirror AI never gets a database account.
        if not set(units)<=dict(store.collection(uid)).keys():raise GameError('ใช้ทีมที่คุณเป็นเจ้าของเท่านั้น')
        self.human=uid
        self.ai=-uid
        self.difficulty=difficulty
        self._initialize(uid,self.ai,[units,list(units)],rng)
        self._aha_apply_settings(store)
        # Aha mirror receives the same pre-match options without writing an AI profile.
        if self.ai in self.aha:
            technique,global_enabled=store.aha_settings(uid)
            self.aha[self.ai]['global']=bool(global_enabled)
            if technique:
                self.aha[self.ai]['punchline']=self.aha_config['technique_start_punchline']
                self.aha_start_notes.append('AI: Technique 20 Punchline · '+self._aha_instant(self.ai))

    def legal_moves(self):
        if self.finished:return []
        actor=self.fighters[self.turn]
        enemies=self.enemies()
        moves=[]
        actions=['attack','guard']
        if actor.unit=='kurumi':actions+=list(BULLETS)
        elif actor.unit=='mami':actions+=['prepare','barrage']
        else:actions+=['skill']
        if actor.unit in ULTIMATES:actions+=['ultimate']
        for action in actions:
            for index,target in enumerate(self.fighters):
                if target.hp<=0:continue
                try:
                    if actor.unit in NEW_NAMES:self._new_validate(actor,action,index)
                    elif index not in enemies:continue
                    if action in ('skill','prepare','barrage') and (actor.cooldown or self.sp[actor.uid]<1):continue
                    if action=='ultimate':
                        if actor.unit=='aha':
                            if self.aha[actor.uid]['wishpower']<self.aha_config['wishpower_cost']:continue
                        elif actor.energy<100:continue
                    moves.append((action,index))
                except GameError:continue
        return moves

    def choose_ai_move(self):
        moves=self.legal_moves()
        if not moves:raise GameError('AI ไม่มีการกระทำที่ถูกต้อง')
        if self.difficulty=='easy':return self.rng.choice(moves)
        actor=self.fighters[self.turn]
        def score(move):
            action,index=move;target=self.fighters[index]
            enemy=target.uid!=actor.uid
            base={'attack':20,'guard':0,'skill':40,'ultimate':70,'prepare':35,'barrage':50,
                  'aleph':15,'bet':12,'dalet':25,'zayin':42,'het':15,'yud':18}[action]
            if action=='skill' and actor.unit=='istaroth':base=20+40*bool(target.stunned)+15*bool(target.cooldown)
            if action=='skill' and actor.unit=='rhinedottir':base=45 if not target.state.get('construct_shots') else 5
            if action=='skill' and actor.unit=='ronova':base=5 if target.state.get('contract')==id(actor) else 45
            if action=='skill' and actor.unit=='aha':base=55 if self.aha[actor.uid]['emanator'] is None else 25
            if action=='prepare':base=45 if actor.state.get('guns',0)<2 else 5
            if action=='dalet':base=target.state.get('last_damage',0) if target.hp<target.max_hp*0.6 else 0
            if enemy:base+=(1-target.hp/target.max_hp)*10
            if self.difficulty=='hard':
                # Prefer exposed/finishable enemies and saving vulnerable allies; no hidden resources.
                if enemy:
                    estimate=actor.max_hp*16//100 if actor.unit=='kuru' else actor.attack
                    if action=='skill':estimate=actor.max_hp*32//100 if actor.unit=='kuru' else actor.attack*2
                    if action=='ultimate':estimate=actor.attack*3
                    if action in ('attack','skill','ultimate','barrage') and target.hp+target.shield<=estimate:base+=100
                else:base+=(1-target.hp/target.max_hp)*30
                if actor.unit=='mala' and action in ('skill','ultimate'):
                    base+=sum((1-f.hp/f.max_hp)*20 for f in self.fighters if f.uid==actor.uid and f.hp>0)
                if action=='guard' and actor.hp<actor.max_hp*0.2:base+=15
            return base
        return max(moves,key=score)

    def run_ai(self):
        notes=[]
        # Core turn limit bounds stun skips and repeated AI turns as well.
        budget=self.limit+1
        while not self.finished and self.fighters[self.turn].uid==self.ai:
            if budget<=0:raise GameError('AI เกินขอบเขตการเดินคิว')
            action,index=self.choose_ai_move()
            notes.append('🤖 AI › '+self.act(self.ai,action,index))
            budget-=1
        return notes
