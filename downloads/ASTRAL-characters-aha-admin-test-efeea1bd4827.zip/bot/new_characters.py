"""Confirmed handoff mechanics. Missing balance values are not silently invented."""
NEW_NAMES={
    'ronova':'Ronova','istaroth':'Istaroth','rhinedottir':'Rhinedottir',
    'asmoday':'Asmoday','kurumi':'Tokisaki Kurumi','aha':'Aeon Aha','mami':'Mami Tomoe',
}
BULLETS=('aleph','bet','dalet','zayin','het','yud')
ACTION_LABELS={'aleph':'Aleph · เร่งคิวเพื่อน','bet':'Bet · ชะลอคิวศัตรู',
    'dalet':'Dalet · ย้อน HP','zayin':'Zayin · หยุดเวลา','het':'Het · สร้างเงา','yud':'Yud · อ่านอดีต',
    'prepare':'Summon Musket · เตรียมปืน/ริบบิ้น','barrage':'Musket Barrage · ยิงปืนทั้งหมด'}
KITS={
    'ronova':'โจมตี 80% ATK; สัญญา 3 เทิร์น สะสมหนี้จาก HP ที่เสียจริง 25% และฮีลจริง 30% เพดาน 40%; อันติทวงหนี้',
    'istaroth':'โจมตี 80% ATK; สกิลล้างสตั้น/ลด CD เพื่อน 1 ไม่เลือกตัวเอง; อันติฮีลทีม 15% และลดอายุ DoT 1',
    'rhinedottir':'โจมตี 80% ATK; สิ่งสร้างผูกเพื่อนยิงช่วย 40% ATK 2 ครั้ง; อันติระเบิดหมู่ 120% ATK และโล่ทีม 10% HP ผู้สร้าง',
    'asmoday':'โจมตี 100% ATK; สกิล 150% และผนึกโล่ใหม่ -50%; อันติหมู่ 160% เพิ่ม 25% ใส่ผู้ติดตราแล้วล้างตรา',
    'kurumi':'โจมตี 100% ATK คืน 1 SP และเวลา 1; กระสุนจ่าย HP ปัจจุบัน 10% + เวลา 1 ยกเว้น Zayin 20% + เวลา 3; อันติพลัง 100 ใช้เวลาทั้งหมดอย่างน้อย 3',
    'mami':'Ribbon Shot 80% ATK เตรียมปืน 1; Summon Musket ใช้ 1 SP เตรียม 2/ผูกริบบิ้น; Barrage 1 SP กระบอกละ 70% ATK; Tiro Finale พลัง 100 + ปืน 3: 360% หรือ 450% ใส่ผู้ติดริบบิ้น',
    'aha':'แอดมินทดลองเท่านั้น: สกิล 1 SP แต่งตั้งทูต + Elation หมู่ คืน 1 SP ครั้งแรกรอบ; อันติใช้ Wishpower 4; มีคิว Instant แยก ไม่ใช้ระบบจ่าย 3 SP ยิงแทรก',
}


def reject(message):
    from game import GameError
    raise GameError(message)


class CharacterMechanics:
    def _new_validate(self,actor,action,index):
        unit=actor.unit
        if unit=='kurumi' and action=='skill':reject('เลือกกระสุน Zafkiel ก่อน')
        special=action in BULLETS or action in ('prepare','barrage')
        if special and not ((unit=='kurumi' and action in BULLETS) or (unit=='mami' and action in ('prepare','barrage'))):
            reject('ตัวละครนี้ใช้ท่านี้ไม่ได้')
        allies=action in ('aleph','dalet','het') or (action=='skill' and unit in ('istaroth','rhinedottir','aha'))
        target=self.fighters[index] if type(index) is int and 0<=index<len(self.fighters) else None
        if target is None or target.hp<=0 or (target.uid==actor.uid)!=allies:
            reject('เลือกเป้าหมายฝ่ายเดียวกัน/ฝ่ายตรงข้ามที่ยังมีชีวิตให้ตรงกับท่า')
        if (action=='aleph' or (unit=='istaroth' and action=='skill')) and target is actor:
            reject('ท่านี้เลือกตัวเองไม่ได้')
        if action in ('aleph','bet') and index not in self.pending:reject('เป้าหมายผ่านคิวของรอบนี้แล้ว')
        if action in BULLETS:
            if actor.hp<=1:reject('ต้องมี HP มากกว่า 1 เพื่อยิงกระสุน')
            if actor.state.get('time',0)<(3 if action=='zayin' else 1):reject('เวลาไม่พอ')
            if action=='zayin' and actor.state.get('zayin_cd',0):reject('Zayin ยังติดคูลดาวน์')
        if unit=='mami' and action=='barrage' and not actor.state.get('guns',0):reject('ยังไม่มีปืนที่เตรียมไว้')
        if unit=='mami' and action=='ultimate' and actor.state.get('guns',0)<3:reject('Tiro Finale ต้องมีปืนครบ 3')
        if unit=='kurumi' and action=='ultimate' and actor.state.get('time',0)<3:reject('อันติต้องมีเวลาอย่างน้อย 3')
        if unit=='ronova' and action=='ultimate' and not any(f.state.get('contract')==id(actor) for f in self.fighters if f.hp>0):
            reject('ยังไม่มีเป้าหมายสัญญาที่ยังมีชีวิต')
        if unit=='rhinedottir' and action=='ultimate' and not any(f.hp>0 and f.state.get('construct_owner')==id(actor) for f in self.fighters):
            reject('ยังไม่มีสิ่งสร้างที่ผูกกับเพื่อนที่ยังมีชีวิต')
        if unit=='ronova' and action=='ultimate' and target.state.get('contract')!=id(actor):reject('เลือกเป้าหมายที่มีสัญญาของ Ronova')
        return target

    def _strike(self,actor,target,damage):
        if target.guard:damage//=2
        target.guard=False
        mark=target.state.pop('yud',None)
        if mark==actor.uid:damage=damage*115//100
        return self._damage(target,damage,source=actor)

    def _give_shield(self,target,amount):
        if target.state.get('seal',0):amount=amount//2
        target.shield+=max(0,amount)

    def _restore(self,target,amount):
        if target.hp<=0:return 0
        cap=target.max_hp*(100-target.state.get('elation_debt',0))//100
        healed=min(max(0,cap-target.hp),max(0,amount))
        target.hp+=healed
        if target.state.get('contract'):
            target.state['debt']=min(target.max_hp*40//100,target.state.get('debt',0)+healed*30//100)
        return healed

    def _new_damage(self,target,amount,source=None,dot=False):
        # HP costs never enter this hook: no shields, damage energy, or debt from costs.
        if amount>0 and not dot and target.state.get('shadow'):
            amount=amount*70//100
            target.state.pop('shadow')
        absorbed=min(target.shield,amount)
        target.shield-=absorbed
        return max(0,amount-absorbed)

    def _after_damage(self,target,lost):
        target.state['last_damage']=lost
        if target.state.get('contract'):
            target.state['debt']=min(target.max_hp*40//100,target.state.get('debt',0)+lost*25//100)
            if target.hp<=0 and not target.state.get('transferred'):
                others=[f for f in self.fighters if f.uid==target.uid and f.hp>0]
                if others:
                    next_target=max(others,key=lambda f:f.hp)
                    next_target.state.update(contract=target.state['contract'],contract_turns=1,
                        debt=min(next_target.max_hp*40//100,target.state['debt']//2),transferred=True)

    def _new_turn_end(self,fighter,skipped=False):
        if fighter.state.get('contract_turns',0):
            fighter.state['contract_turns']-=1
            if not fighter.state['contract_turns']:
                for name in ('contract','contract_turns','debt','transferred'):fighter.state.pop(name,None)
        if fighter.state.get('seal',0):fighter.state['seal']-=1
        for other in self.fighters:
            if other.state.get('ribbon_owner')==id(fighter):
                other.state['ribbon_turns']-=1
                if other.state['ribbon_turns']<=0:other.state.pop('ribbon_owner',None)

    def _after_normal_attack(self,actor,target):
        if actor.state.get('construct_shots',0):
            owner=next((f for f in self.fighters if id(f)==actor.state.get('construct_owner')),None)
            if owner and owner.hp>0 and target.hp>0:
                self._strike(owner,target,owner.attack*40//100)
                actor.state['construct_shots']-=1
                if not actor.state['construct_shots']:
                    owner.energy=min(100,owner.energy+15)
                    actor.state.pop('construct_owner',None)

    def _new_action(self,actor,target,action,shot_targets=None):
        """Execute validated C0 kit. Return None to use the established original kit."""
        unit=actor.unit
        if unit not in NEW_NAMES or unit=='aha':return None
        if action=='guard':return None
        enemies=[f for f in self.fighters if f.uid!=actor.uid and f.hp>0]
        if action in BULLETS:
            percent,cost=(20,3) if action=='zayin' else (10,1)
            actor.hp=max(1,actor.hp-max(1,actor.hp*percent//100))
            actor.state['time']-=cost
            spent=actor.state.get('spent_time',0)+cost
            if spent>=3:actor.state['shadow']=True
            actor.state['spent_time']=spent%3
            if action in ('aleph','bet'):
                index=self.fighters.index(target)
                if index not in self.pending:reject('เป้าหมายผ่านคิวของรอบนี้แล้ว')
                position=self.pending.index(index)
                new=max(0,position-1) if action=='aleph' else min(len(self.pending)-1,position+1)
                self.pending.pop(position);self.pending.insert(new,index)
            elif action=='dalet':self._restore(target,min(target.state.get('last_damage',0),target.max_hp*25//100))
            elif action=='zayin':target.stunned=1;actor.state['zayin_cd']=3
            elif action=='het':target.state['shadow']=True
            elif action=='yud':target.state['yud']=actor.uid
            return ACTION_LABELS[action]
        if action=='attack':
            scale=100 if unit in ('asmoday','kurumi') else 80
            damage=actor.attack*scale//100
            self._strike(actor,target,damage)
            if unit=='kurumi':actor.state['time']=min(6,actor.state.get('time',0)+1)
            if unit=='mami':actor.state['guns']=min(3,actor.state.get('guns',0)+1)
            # Conservative test policy: debt additions require this Ronova's contract.
            if unit=='ronova' and target.state.get('contract')==id(actor):
                target.state['debt']=min(target.max_hp*40//100,target.state.get('debt',0)+actor.max_hp*5//100)
            if unit=='asmoday' and target.state.get('seal',0) and not target.state.get('seal_extended'):
                target.state['seal']+=1;target.state['seal_extended']=True
            return f'โจมตี {damage} · {target.unit}'
        if action in ('skill','prepare','barrage'):
            if unit=='ronova':
                for f in self.fighters:
                    if f.state.get('contract')==id(actor):
                        for name in ('contract','contract_turns','debt','transferred','contract_pending_expire'):f.state.pop(name,None)
                target.state.update(contract=id(actor),contract_turns=3,debt=0,transferred=False)
            elif unit=='istaroth':
                if target.stunned:
                    target.stunned=0
                    if actor.state.get('cleanse_round')!=self.field_round:
                        actor.energy=min(100,actor.energy+10);actor.state['cleanse_round']=self.field_round
                target.cooldown=max(0,target.cooldown-1)
            elif unit=='rhinedottir':
                for f in self.fighters:
                    if f.state.get('construct_owner')==id(actor):f.state['construct_shots']=0
                target.state.update(construct_owner=id(actor),construct_shots=2)
            elif unit=='asmoday':
                self._strike(actor,target,actor.attack*150//100)
                if target.hp>0:target.state.update(seal=1,seal_extended=False)
            elif unit=='mami':
                if action in ('skill','prepare'):
                    actor.state['guns']=min(3,actor.state.get('guns',0)+2)
                    target.state.update(ribbon_owner=id(actor),ribbon_turns=2)
                else:
                    guns=actor.state.get('guns',0)
                    actor.state['guns']=0
                    chosen=shot_targets or [self.fighters.index(target)]
                    previous=None;streak=0
                    for shot in range(guns):
                        victim=self.fighters[chosen[min(shot,len(chosen)-1)]]
                        if victim.hp<=0:continue
                        streak=streak+1 if victim is previous else 0
                        damage=actor.attack*70//100
                        if victim.state.get('ribbon_owner')==id(actor):damage=damage*(100+15*streak)//100
                        self._strike(actor,victim,damage)
                        previous=victim
            return ACTION_LABELS.get(action,'ใช้สกิล')
        if action=='ultimate':
            if unit=='ronova':
                debt=target.state.pop('debt',0)
                for name in ('contract','contract_turns','transferred','contract_pending_expire'):target.state.pop(name,None)
                self._strike(actor,target,debt)
            elif unit=='istaroth':
                for friend in self.fighters:
                    if friend.uid==actor.uid and friend.hp>0:
                        self._restore(friend,friend.max_hp*15//100);friend.bleed=max(0,friend.bleed-1)
            elif unit=='rhinedottir':
                for f in self.fighters:
                    if f.state.get('construct_owner')==id(actor):f.state['construct_shots']=0;f.state.pop('construct_owner',None)
                for enemy in enemies:self._strike(actor,enemy,actor.attack*120//100)
                for friend in self.fighters:
                    if friend.uid==actor.uid and friend.hp>0:self._give_shield(friend,actor.max_hp*10//100)
            elif unit=='asmoday':
                for enemy in enemies:
                    damage=actor.attack*160//100
                    if enemy.state.get('seal',0):damage=damage*125//100
                    enemy.state.pop('seal',None);enemy.state.pop('seal_extended',None)
                    self._strike(actor,enemy,damage)
            elif unit=='kurumi':
                time=actor.state.pop('time',0)
                self._strike(actor,target,actor.attack*(240+20*time)//100)
                spent=actor.state.get('spent_time',0)+time
                if spent>=3:actor.state['shadow']=True
                actor.state['spent_time']=spent%3
            elif unit=='mami':
                actor.state['guns']=0
                self._strike(actor,target,actor.attack*(450 if target.state.get('ribbon_owner')==id(actor) else 360)//100)
            return 'ใช้อันติ'
        return None
