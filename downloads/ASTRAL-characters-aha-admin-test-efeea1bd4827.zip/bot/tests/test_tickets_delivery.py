import os
os.environ['GACHA_DB']=':memory:'
import sqlite3
import asyncio
import tempfile
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from types import SimpleNamespace
from unittest.mock import AsyncMock,MagicMock,patch
import bot
from game import Store,GameError

class Fixed:
    def random(self):return .99
    def choice(self,items):return items[0]

class TicketTests(unittest.TestCase):
    def setUp(self):self.store=Store(':memory:')
    def tearDown(self):self.store.db.close()
    def give(self,code='TICKETS',uid=2,character=12,skin=4):
        self.store.create_code(code,1,10,100,'kuru',1,int(time.time())+1000,20,character,skin)
        self.store.redeem(uid,code)

    def test_combined_rewards_record_exact_ticket_audit(self):
        self.give()
        self.assertEqual(self.store.ticket_balance(2),(12,4))
        self.assertEqual(self.store.profile(2)[0],1100)
        self.assertEqual(dict(self.store.collection(2))['kuru'],1)
        self.assertEqual(self.store.db.execute('SELECT character_tickets,skin_tickets FROM code_claims').fetchone(),(12,4))
        with self.assertRaises(GameError):self.store.redeem(2,'tickets')
        self.assertEqual(self.store.ticket_balance(2),(12,4))

    def test_ticket_only_code_and_validation(self):
        self.store.create_code('ONLY',1,10,0,'',0,int(time.time())+1000,1,2,3)
        self.store.redeem(2,'ONLY')
        self.assertEqual(self.store.ticket_balance(2),(2,3))
        for amount in (-1,True,1_000_001):
            with self.assertRaises(GameError):self.store.create_code('INVALID',1,10,0,'',0,int(time.time())+1000,1,amount,0)

    def test_ticket_spending_each_banner_shares_pity_with_gems(self):
        for index,banner in enumerate(('standard','kuru','yuko')):
            uid=20+index
            self.give('BANNER'+str(index),uid)
            before=self.store.profile(uid)[0]
            self.store.pull_many(uid,1,Fixed(),banner,payment='tickets')
            self.assertEqual(self.store.guarantees(uid,banner),(1,1))
            self.assertEqual(self.store.profile(uid)[0],before)
            self.store.pull_many(uid,1,Fixed(),banner,payment='gems')
            self.assertEqual(self.store.guarantees(uid,banner),(2,2))
            self.assertEqual(self.store.ticket_balance(uid),(11,4))
            self.assertEqual(self.store.profile(uid)[0],before-100)

    def test_ten_tickets_deduct_exactly_ten_without_gems(self):
        self.give()
        self.assertEqual(len(self.store.pull_many(2,10,Fixed(),payment='tickets')),10)
        self.assertEqual(self.store.ticket_balance(2),(2,4))
        self.assertEqual(self.store.profile(2)[0],1100)
        self.assertEqual(self.store.guarantees(2),(10,0))

    def test_insufficient_tickets_never_fall_back_to_gems(self):
        self.give(character=1)
        before=self.store.collection(2)
        with self.assertRaises(GameError):self.store.pull_many(2,10,Fixed(),payment='tickets')
        self.assertEqual(self.store.ticket_balance(2),(1,4))
        self.assertEqual(self.store.profile(2)[0],1100)
        self.assertEqual(self.store.collection(2),before)
        self.assertEqual(self.store.guarantees(2),(0,0))
        with patch.dict(os.environ,{'KURU_BANNER_OPEN':'false'}):
            with self.assertRaises(GameError):self.store.pull_many(2,1,Fixed(),'kuru',payment='tickets')
        self.assertEqual(self.store.ticket_balance(2),(1,4))

    def test_failed_roll_restores_tickets_pity_and_collection(self):
        class Broken(Fixed):
            calls=0
            def random(self):
                self.calls+=1
                if self.calls==2:raise RuntimeError('synthetic failure')
                return .99
        self.give()
        before=self.store.collection(2)
        with self.assertRaises(RuntimeError):self.store.pull_many(2,10,Broken(),'kuru',payment='tickets')
        self.assertEqual(self.store.ticket_balance(2),(12,4))
        self.assertEqual(self.store.collection(2),before)
        self.assertEqual(self.store.guarantees(2,'kuru'),(0,0))

    def test_ticket_cap_or_claim_failure_rolls_back_all_rewards(self):
        self.give()
        with self.store.db:self.store.db.execute('UPDATE ticket_wallet SET skin_tickets=1000000000 WHERE player=2')
        self.store.create_code('SECOND',1,10,100,'kuru',2,int(time.time())+1000,1,3,1)
        with self.assertRaises(GameError):self.store.redeem(2,'SECOND')
        self.assertEqual(self.store.profile(2)[0],1100)
        self.assertEqual(dict(self.store.collection(2))['kuru'],1)
        self.assertEqual(self.store.ticket_balance(2),(12,1_000_000_000))
        self.assertEqual(self.store.code_history(10,'SECOND')[0][3],0)
        self.store.db.execute("CREATE TRIGGER fail_claim BEFORE INSERT ON code_claims BEGIN SELECT RAISE(ABORT,'failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):self.store.redeem(3,'SECOND')
        self.assertEqual(self.store.ticket_balance(3),(0,0))
        self.assertIsNone(self.store.db.execute('SELECT 1 FROM players WHERE id=3').fetchone())

    def test_previous_redeem_schema_migration_is_repeatable_and_preserves_claim(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'old.db'
            db=sqlite3.connect(path)
            db.executescript('''
            CREATE TABLE reward_codes(code TEXT PRIMARY KEY,guild INTEGER NOT NULL,actor INTEGER NOT NULL,created INTEGER NOT NULL,expires INTEGER NOT NULL,max_uses INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,gems INTEGER NOT NULL,unit TEXT NOT NULL,copies INTEGER NOT NULL);
            CREATE TABLE code_claims(code TEXT NOT NULL,player INTEGER NOT NULL,time INTEGER NOT NULL,gems INTEGER NOT NULL,unit TEXT NOT NULL,copies INTEGER NOT NULL,PRIMARY KEY(code,player));
            INSERT INTO reward_codes VALUES('OLD',10,1,1,4102444800,10,1,1,500,'kuru',1);
            INSERT INTO code_claims VALUES('OLD',2,2,500,'kuru',1);
            ''')
            db.close()
            for _ in range(2):
                store=Store(path)
                self.assertEqual(store.code_tickets('OLD'),(0,0))
                self.assertEqual(store.db.execute('SELECT gems,unit,copies FROM code_claims').fetchone(),(500,'kuru',1))
                with self.assertRaises(GameError):store.redeem(2,'OLD')
                self.assertEqual(store.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
                store.db.close()

    def test_concurrent_ticket_pulls_cannot_spend_same_ticket_twice(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'race.db'
            store=Store(path)
            store.create_code('ONE',1,10,0,'',0,int(time.time())+1000,1,1,0)
            store.redeem(2,'ONE');store.db.close()
            barrier=Barrier(2)
            def pull():
                s=Store(path)
                try:
                    barrier.wait(timeout=5)
                    try:s.pull_many(2,1,Fixed(),payment='tickets');return True
                    except GameError:return False
                finally:s.db.close()
            with ThreadPoolExecutor(max_workers=2) as pool:
                tasks=[pool.submit(pull) for _ in range(2)]
                self.assertEqual(sum(t.result(timeout=10) for t in tasks),1)
            s=Store(path)
            self.assertEqual(s.ticket_balance(2),(0,0))
            self.assertEqual(s.profile(2)[0],1000)
            self.assertEqual(s.guarantees(2),(1,1));s.db.close()

    def test_ticket_inventory_and_consumed_claim_survive_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'save.db'
            s=Store(path)
            s.create_code('SAVE',1,10,0,'',0,int(time.time())+1000,2,3,4)
            s.redeem(2,'SAVE');s.pull_many(2,1,Fixed(),'kuru',payment='tickets');s.db.close()
            s=Store(path)
            self.assertEqual(s.ticket_balance(2),(2,4))
            self.assertEqual(s.guarantees(2,'kuru'),(1,1))
            with self.assertRaises(GameError):s.redeem(2,'SAVE')
            self.assertEqual(s.db.execute('PRAGMA integrity_check').fetchone()[0],'ok');s.db.close()

class DeliveryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.store=Store(':memory:')
        self.patcher=patch.object(bot,'store',self.store);self.patcher.start()
        self.settings=patch.dict(os.environ,{'ADMIN_GUILD_ID':'10','DISCORD_GUILD_ID':''});self.settings.start()
        self.channel=MagicMock(spec=bot.discord.TextChannel)
        self.channel.id=100;self.channel.guild=SimpleNamespace(id=10)
        self.channel.send=AsyncMock(return_value=SimpleNamespace(id=999))
        self.channel.permissions_for.return_value=bot.discord.Permissions(view_channel=True,send_messages=True,embed_links=True)
        self.guild=SimpleNamespace(id=10,me=object(),get_channel=lambda cid:self.channel if cid==100 else None)
        self.i=SimpleNamespace(user=SimpleNamespace(id=2),guild_id=10,guild=self.guild,
            permissions=bot.discord.Permissions(administrator=True),response=SimpleNamespace(send_message=AsyncMock(),defer=AsyncMock()),followup=SimpleNamespace(send=AsyncMock()))

    def tearDown(self):self.settings.stop();self.patcher.stop();self.store.db.close()

    async def configure(self):await bot.admin_update_channel.callback(self.i,self.channel)

    async def test_configure_publish_categories_history_and_no_duplicate(self):
        await self.configure()
        await bot.admin_update_publish.callback(self.i,'V1','ข่าว',added='ตั๋ว',balance='สมดุล',fixed='บั๊ก')
        self.assertEqual(self.store.update_channel(10),100)
        body=self.store.updates('v1')[0][3]
        for text in ('เพิ่มใหม่','ปรับสมดุล','แก้บั๊ก','ตั๋ว','บั๊ก'):self.assertIn(text,body)
        self.channel.send.assert_awaited_once()
        self.assertEqual(self.store.delivery_history(10),[('v1',100,'sent',999)])
        mentions=self.channel.send.await_args.kwargs['allowed_mentions']
        self.assertFalse(mentions.everyone);self.assertFalse(mentions.users);self.assertFalse(mentions.roles)
        with self.assertRaises(GameError):await bot.admin_update_publish.callback(self.i,'v1','ซ้ำ','ซ้ำ')
        with self.assertRaises(GameError):await bot.admin_update_announce.callback(self.i,'V1')
        self.channel.send.assert_awaited_once()

    async def test_missing_channel_or_permissions_block_before_log_write(self):
        with self.assertRaises(GameError):await bot.admin_update_publish.callback(self.i,'v1','ข่าว','รายละเอียด')
        self.assertEqual(self.store.updates(),[])
        self.channel.permissions_for.return_value=bot.discord.Permissions.none()
        with self.assertRaises(GameError):await self.configure()
        self.assertIsNone(self.store.update_channel(10))
        self.store.set_update_channel(10,100)
        with self.assertRaises(GameError):await bot.admin_update_publish.callback(self.i,'v1','ข่าว','รายละเอียด')
        self.channel.send.assert_not_awaited()
        self.assertEqual(self.store.updates(),[])

    async def test_uncertain_delivery_is_preserved_and_never_retried(self):
        await self.configure()
        self.channel.send.side_effect=TimeoutError('unknown delivery')
        with self.assertRaises(GameError):await bot.admin_update_publish.callback(self.i,'v1','ข่าว','รายละเอียด')
        self.assertTrue(self.store.updates('v1'))
        self.assertEqual(self.store.delivery_history(10)[0][2],'uncertain')
        self.channel.send.side_effect=None
        with self.assertRaises(GameError):await bot.admin_update_announce.callback(self.i,'v1')
        self.channel.send.assert_awaited_once()
        await bot.admin_update_status.callback(self.i)
        self.assertIn('ห้ามส่งซ้ำ',self.i.response.send_message.await_args.kwargs['embed'].description)

    async def test_old_versions_can_be_announced_once_and_attempt_survives_reopen(self):
        await self.configure()
        self.store.publish_update('old',2,10,'เก่า','เนื้อหา')
        await bot.admin_update_announce.callback(self.i,'OLD')
        with self.assertRaises(GameError):await bot.admin_update_announce.callback(self.i,'old')
        self.channel.send.assert_awaited_once()
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'delivery.db'
            s=Store(path);s.publish_update('v1',1,10,'ข่าว','เนื้อหา')
            s.set_update_channel(10,100);s.reserve_update_delivery('v1',10,100);s.db.close()
            s=Store(path)
            self.assertEqual(s.update_channel(10),100)
            self.assertEqual(s.delivery_history(10)[0][2],'sending')
            with self.assertRaises(GameError):s.reserve_update_delivery('v1',10,100)
            # Same global log may be announced once in another guild.
            s.reserve_update_delivery('v1',11,110);s.finish_update_delivery('v1',11,123)
            self.assertEqual(s.delivery_history(11)[0][2],'sent');s.db.close()

    async def test_permissions_for_new_admin_commands_are_checked_twice(self):
        calls=[(bot.admin_update_channel,(self.channel,)),(bot.admin_update_announce,('v1',)),(bot.admin_update_status,())]
        for command,args in calls:
            self.i.permissions=bot.discord.Permissions.none()
            with self.assertRaises(GameError):await command.callback(self.i,*args)
            for check in command.checks:
                with self.assertRaises(bot.app_commands.MissingPermissions):await check(self.i)
            self.i.permissions=bot.discord.Permissions(administrator=True)
            self.i.guild_id=11
            with self.assertRaises(GameError):await command.callback(self.i,*args)
            self.i.guild_id=10
        self.channel.send.assert_not_awaited()

    async def test_wrong_guild_channel_cannot_be_selected(self):
        self.channel.guild=SimpleNamespace(id=11)
        with self.assertRaises(GameError):await self.configure()
        self.assertIsNone(self.store.update_channel(10))

    async def test_simultaneous_announcement_requests_only_send_once(self):
        self.store.publish_update('v1',2,10,'ข่าว','เนื้อหา')
        results=await asyncio.gather(bot.deliver_update('v1',10,self.channel),bot.deliver_update('V1',10,self.channel),return_exceptions=True)
        self.assertEqual(sum(isinstance(r,GameError) for r in results),1)
        self.channel.send.assert_awaited_once()
        self.assertEqual(self.store.delivery_history(10),[('v1',100,'sent',999)])

    async def test_private_ticket_buttons_charge_clicker_and_display_currency(self):
        self.store.create_code('TICKET',1,10,0,'',0,int(time.time())+1000,1,1,0)
        self.store.redeem(2,'TICKET')
        view=bot.SummonView('kuru','tickets')
        await view.single.callback(self.i)
        self.assertEqual(self.store.ticket_balance(2),(0,0))
        self.assertEqual(self.store.profile(2)[0],1000)
        kwargs=self.i.response.send_message.await_args.kwargs
        self.assertTrue(kwargs['ephemeral'])
        self.assertIn('1 ตั๋วตัวละคร',kwargs['embed'].description)
        self.assertNotIn('ใช้ **100',kwargs['embed'].description)
        self.assertIn('ตั๋ว 1 ใบ',view.single.label)
        view.stop()
