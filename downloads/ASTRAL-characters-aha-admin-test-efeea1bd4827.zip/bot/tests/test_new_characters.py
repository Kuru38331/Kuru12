import os
os.environ['GACHA_DB']=':memory:'
import copy
import random
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock
import bot
from game import Battle,TeamBattle,Store,GameError,CATALOG,FEATURED,OFF_RATE
from presentation import character_embed,banner_embed

class Fixed:
    def randrange(self,n):return 0
    def random(self):return .99
    def choice(self,items):return items[0]

class CharacterTests(unittest.TestCase):
    def setUp(self):self.s=Store(':memory:')
    def tearDown(self):self.s.db.close()
    def team(self,first,second=('dragon','knight','mage','paladin')):
        for uid,units in ((1,first),(2,second)):
            self.s.profile(uid)
            with self.s.db:
                for unit in units:self.s.db.execute('INSERT OR IGNORE INTO units VALUES(?,?,1)',(uid,unit))
            self.s.set_lineup(uid,list(units))
        return TeamBattle(1,2,self.s,Fixed())
    def duel(self,unit,enemy='dragon'):
        for uid,key in ((1,unit),(2,enemy)):
            self.s.profile(uid)
            with self.s.db:self.s.db.execute('INSERT OR IGNORE INTO units VALUES(?,?,1)',(uid,key))
            self.s.equip(uid,key)
        return Battle(1,2,self.s,Fixed())
    def force(self,b,index):
        b.turn=index
        position=b.order.index(index)
        b.pending=b.order[position+1:]+b.order[:position]
    def snapshot(self,b):return copy.deepcopy((b.sp,b.rounds,b.turn,b.pending,[vars(f) for f in b.fighters]))

    def test_new_pool_equal_choice_and_limited_exclusion(self):
        self.assertEqual(OFF_RATE,('eiji','ronova','istaroth','rhinedottir','asmoday'))
        for i,key in enumerate(OFF_RATE):
            class Lose(Fixed):
                def random(self):return 0 if not hasattr(self,'rolled') else .99
                def choice(self,items):
                    self.items=items
                    return items[i]
            class Roll:
                def __init__(self):self.calls=0;self.pool=None
                def random(self):self.calls+=1;return 0 if self.calls==1 else .99
                def choice(self,items):self.pool=list(items);return items[i]
            rng=Roll();unit=self.s.pull(10+i,rng,banner='kurumi')
            self.assertEqual(unit,key);self.assertEqual(rng.pool,list(OFF_RATE))
            self.assertEqual(self.s.pull(10+i,Fixed(),banner='kurumi'),'knight')
            self.assertTrue(self.s.featured_guaranteed(10+i,'kurumi'))
        self.assertEqual(set(FEATURED),{'kuru','yuko','kurumi','mami'})
        self.assertIn('aha',CATALOG)
        self.assertNotIn('aha',FEATURED)
        with self.assertRaises(GameError):self.s.create_code('AHA',1,10,0,'aha',1,4102444800,1)
        self.assertIn('dragon',CATALOG)
        self.assertIn('แอดมินทดลอง',character_embed('aha').description)

    def test_team_sp_shared_capped_and_guard_does_not_restore(self):
        b=self.team(('asmoday','eiji','yuko','mala'))
        b.act(1,'skill',4);self.assertEqual(b.sp[1],2)
        self.force(b,1);b.act(1,'skill',4);self.assertEqual(b.sp[1],1)
        self.force(b,2);before=b.sp[1];b.act(1,'guard',4);self.assertEqual(b.sp[1],before)
        b.sp[1]=5;self.force(b,3);b.act(1,'attack',4);self.assertEqual(b.sp[1],5)
        self.assertEqual(b.sp[2],3)

    def test_ronova_contract_actual_loss_healing_cap_and_debt_collection(self):
        b=self.duel('ronova');a,t=b.fighters
        b.act(1,'skill',1)
        b._damage(t,40);self.assertEqual(t.state['debt'],10)
        b._restore(t,20);self.assertEqual(t.state['debt'],16)
        b._restore(t,999);self.assertEqual(t.hp,t.max_hp)
        self.assertLessEqual(t.state['debt'],t.max_hp*40//100)
        debt=t.state['debt'];a.energy=100;t.guard=True;self.force(b,0)
        hp=t.hp;b.act(1,'ultimate',1)
        self.assertEqual(t.hp,hp-debt//2)
        self.assertNotIn('contract',t.state)
        self.assertEqual(a.energy,0)

    def test_ronova_expiry_and_single_transfer(self):
        b=self.team(('ronova','eiji','kuru','mala'));a=b.fighters[0];t=b.fighters[4]
        b.act(1,'skill',4)
        for _ in range(3):b._new_turn_end(t,skipped=True)
        self.assertNotIn('contract',t.state)
        t.state.update(contract=id(a),contract_turns=3,debt=40,transferred=False)
        b._damage(t,9999)
        transferred=[f for f in b.fighters if f.hp>0 and f.state.get('contract')==id(a)]
        self.assertEqual(len(transferred),1)
        next_target=transferred[0];self.assertTrue(next_target.state['transferred'])
        b._damage(next_target,9999)
        self.assertFalse(any(f.hp>0 and f.state.get('contract')==id(a) for f in b.fighters))

    def test_istaroth_cleanse_cd_and_team_heal(self):
        b=self.team(('istaroth','kuru','eiji','mala'));a,t=b.fighters[:2]
        t.stunned=1;t.cooldown=3
        b.act(1,'skill',1)
        self.assertEqual((t.stunned,t.cooldown),(0,2));self.assertEqual(a.energy,45)
        before=self.snapshot(b);self.force(b,0);before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'skill',0)
        self.assertEqual(self.snapshot(b),before)
        for f in b.fighters[:4]:f.hp=f.max_hp//2;f.bleed=3
        self.force(b,0);a.energy=100;b.act(1,'ultimate',4)
        self.assertEqual(t.hp,t.max_hp//2+t.max_hp*15//100)
        self.assertEqual(t.bleed,2)

    def test_construct_shoots_with_original_character_not_fifth_slot(self):
        b=self.team(('rhinedottir','eiji','kuru','mala'));a=b.fighters[0];holder=b.fighters[1];target=b.fighters[4]
        b.act(1,'skill',1)
        self.assertEqual(len(b.fighters),8)
        self.force(b,1);hp=target.hp;b.act(1,'attack',4)
        self.assertEqual(hp-target.hp,holder.attack+a.attack*40//100)
        self.assertEqual(holder.state['construct_shots'],1)
        self.force(b,1);b.act(1,'attack',4)
        self.assertEqual(holder.state['construct_shots'],0)
        self.assertEqual(a.energy,50)

    def test_construct_ultimate_requires_construct_and_gives_shields(self):
        b=self.duel('rhinedottir');a,t=b.fighters;a.energy=100
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'ultimate',1)
        self.assertEqual(before,self.snapshot(b))
        b.act(1,'skill',0)
        self.force(b,0);a.energy=100;b.act(1,'ultimate',1)
        self.assertEqual(a.shield,a.max_hp*10//100)
        self.assertEqual(a.state.get('construct_shots'),0)
        self.assertEqual(t.hp,t.max_hp-a.attack*120//100)

    def test_asmoday_seal_shields_and_aoe_bonus(self):
        b=self.team(('asmoday','eiji','kuru','mala'));a,t=b.fighters[0],b.fighters[4]
        b.act(1,'skill',4)
        b._give_shield(t,20);self.assertEqual(t.shield,10)
        a.energy=100;self.force(b,0)
        expected=a.attack*160//100*125//100
        before=t.hp;b.act(1,'ultimate',4)
        self.assertEqual(t.hp,before-max(0,expected-10))
        self.assertFalse(t.state.get('seal'))
        self.assertTrue(all(f.hp<f.max_hp for f in b.fighters[4:]))

    def test_kurumi_invalid_bullet_is_atomic_and_cost_bypasses_shield(self):
        b=self.duel('kurumi');a,t=b.fighters
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'zayin',1)
        self.assertEqual(self.snapshot(b),before)
        a.state['time']=3;a.shield=99;hp=a.hp
        b.act(1,'zayin',1)
        self.assertEqual(a.hp,hp-hp*20//100)
        self.assertEqual(a.shield,99)
        self.assertEqual(a.state.get('time'),0)
        self.assertTrue(a.state.get('shadow'))
        self.assertEqual(b.sp[1],3)
        self.assertEqual(a.energy,35)
        self.assertEqual(b.turn,0)
        before=self.snapshot(b)
        a.state['time']=3;before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'zayin',1)
        self.assertEqual(self.snapshot(b),before)

    def test_kurumi_one_hp_cannot_fire_and_attack_earns_time_sp(self):
        b=self.duel('kurumi');a,t=b.fighters
        a.hp=1;a.state['time']=3
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'het',0)
        self.assertEqual(before,self.snapshot(b))
        b.act(1,'attack',1)
        self.assertEqual(a.state['time'],4);self.assertEqual(b.sp[1],4)

    def test_kurumi_dalet_het_yud_and_ultimate(self):
        b=self.duel('kurumi');a,t=b.fighters
        b._damage(a,50);a.state['time']=5
        b.act(1,'dalet',0)
        self.assertEqual(a.hp,a.max_hp-50-(a.max_hp-50)*10//100+a.max_hp*25//100)
        self.force(b,0);a.cooldown=0;b.act(1,'het',0)
        hp=a.hp;b._damage(a,50);self.assertEqual(hp-a.hp,35)
        self.assertFalse(a.state.get('shadow'))
        self.force(b,0);b.act(1,'yud',1)
        hp=t.hp;self.force(b,0);b.act(1,'attack',1)
        self.assertEqual(hp-t.hp,a.attack*115//100)
        self.force(b,0);a.energy=100;a.state['time']=3;t.hp=t.max_hp
        b.act(1,'ultimate',1)
        self.assertEqual(t.hp,t.max_hp-a.attack*300//100)
        self.assertEqual(a.energy,0);self.assertNotIn('time',a.state)

    def test_kurumi_queue_shift_no_new_turn_and_invalid_spent_slot_atomic(self):
        b=self.team(('kurumi','eiji','yuko','mala'));a=b.fighters[0];a.state['time']=3
        order=list(b.pending);b.act(1,'aleph',1)
        self.assertEqual(set(b.pending+[b.turn]),set(order))
        self.assertEqual(b.rounds,1)
        self.force(b,0);b.pending=[4,1,5,2,6,3,7]
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'aleph',0)
        self.assertEqual(before,self.snapshot(b))
        b.pending=[];before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'bet',4)
        self.assertEqual(before,self.snapshot(b))

    def test_shadow_never_absorbs_dot_and_shield_actual_hp_loss(self):
        b=self.duel('kurumi');a,t=b.fighters
        a.state['shadow']=True;hp=a.hp;b._damage(a,10,dot=True)
        self.assertEqual(hp-a.hp,10);self.assertTrue(a.state['shadow'])
        a.shield=20;hp=a.hp;b._damage(a,10)
        self.assertEqual(a.hp,hp);self.assertEqual(a.shield,13)

    def test_mami_guns_ribbon_ultimate_and_invalid_costs(self):
        b=self.duel('mami');a,t=b.fighters;a.energy=100
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'ultimate',1)
        self.assertEqual(before,self.snapshot(b))
        b.act(1,'attack',1);self.assertEqual(a.state['guns'],1)
        self.force(b,0);b.act(1,'prepare',1)
        self.assertEqual(a.state['guns'],3);self.assertEqual(b.sp[1],3)
        self.force(b,0);a.energy=100;t.hp=t.max_hp
        b.act(1,'ultimate',1)
        self.assertEqual(t.hp,t.max_hp-a.attack*450//100)
        self.assertEqual(a.state['guns'],0)
        self.assertEqual(a.energy,0)

    def test_mami_barrage_split_and_invalid_target_rollback(self):
        b=self.team(('mami','eiji','yuko','mala'));a=b.fighters[0];a.state['guns']=3
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'barrage',4,shot_targets=[4,1])
        self.assertEqual(before,self.snapshot(b))
        hp4,hp5=b.fighters[4].hp,b.fighters[5].hp
        b.act(1,'barrage',4,shot_targets=[4,5])
        self.assertEqual(hp4-b.fighters[4].hp,a.attack*70//100)
        self.assertEqual(hp5-b.fighters[5].hp,2*(a.attack*70//100))
        self.assertEqual(a.state['guns'],0);self.assertEqual(b.sp[1],2)

    def test_exhausted_construct_cannot_be_exploded(self):
        b=self.duel('rhinedottir');a,t=b.fighters
        b.act(1,'skill',0)
        for _ in range(2):
            self.force(b,0);t.hp=t.max_hp;b.act(1,'attack',1)
        self.force(b,0);a.energy=100
        before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'ultimate',1)
        self.assertEqual(before,self.snapshot(b))

    def test_yud_boost_applies_to_original_teammate(self):
        b=self.team(('kurumi','eiji','yuko','mala'));a=b.fighters[0];a.state['time']=1
        b.act(1,'yud',4)
        self.force(b,1);target=b.fighters[4];hp=target.hp
        b.act(1,'attack',4)
        self.assertEqual(hp-target.hp,b.fighters[1].attack*115//100)
        self.assertNotIn('yud',target.state)

    def test_mami_ribbon_is_usable_on_next_turn_and_bonus_resets_when_split(self):
        b=self.team(('mami','eiji','yuko','mala'));a=b.fighters[0]
        b.act(1,'prepare',4)
        self.assertEqual(a.state['guns'],2)
        self.assertEqual(a.cooldown,0)
        self.force(b,0);target=b.fighters[4];hp=target.hp
        b.act(1,'barrage',4)
        base=a.attack*70//100
        self.assertEqual(hp-target.hp,base+base*115//100)
        self.assertNotIn('ribbon_owner',target.state)

    def test_zayin_requires_three_completed_actions_before_reuse(self):
        b=self.duel('kurumi');a,t=b.fighters;a.state['time']=6
        b.act(1,'zayin',1)
        for _ in range(3):
            self.force(b,0)
            before=self.snapshot(b)
            with self.assertRaises(GameError):b.act(1,'zayin',1)
            self.assertEqual(before,self.snapshot(b))
            b.act(1,'guard',1)
        self.force(b,0);b.act(1,'zayin',1)
        self.assertEqual(a.state['time'],0)

    def test_invalid_custom_actions_do_not_mutate_original_characters(self):
        b=self.duel('kuru');before=self.snapshot(b)
        with self.assertRaises(GameError):b.act(1,'barrage',1)
        self.assertEqual(before,self.snapshot(b))

    def test_full_matches_new_kits_end_with_valid_resources(self):
        for first,second in [(('ronova','istaroth','rhinedottir','asmoday'),('kurumi','mami','eiji','mala'))]:
            b=self.team(first,second);rng=random.Random(41)
            while not b.finished:
                a=b.fighters[b.turn]
                enemies=b.enemies();target=enemies[0]
                options=['attack','guard']
                if a.unit=='kurumi':
                    if a.state.get('time',0)>=1 and a.hp>1:options+=['het','yud']
                elif a.cooldown==0 and b.sp[a.uid]>=1:options+=['skill']
                action=rng.choice(options)
                if action=='skill' and a.unit in ('istaroth','rhinedottir'):
                    allies=[i for i,f in enumerate(b.fighters) if f.uid==a.uid and f.hp>0 and (f is not a or a.unit=='rhinedottir')]
                    if not allies:action='attack'
                    else:target=allies[0]
                if action=='het':target=b.turn
                b.act(a.uid,action,target)
                self.assertTrue(all(0<=f.hp<=f.max_hp and f.shield>=0 for f in b.fighters))
                self.assertTrue(all(0<=n<=5 for n in b.sp.values()))
            self.assertLessEqual(b.rounds,b.limit)

class NewUITests(unittest.IsolatedAsyncioTestCase):
    async def test_cards_banners_and_command_choices_include_new_ready_characters(self):
        for key in ('ronova','istaroth','rhinedottir','asmoday','kurumi','mami'):
            embed=character_embed(key)
            self.assertIn('ทดลอง',embed.title)
            self.assertLess(len(embed),6000)
        for key in ('kurumi','mami'):
            self.assertIn('ทดลอง',str(banner_embed(key).to_dict()))
        for command in bot.bot.tree.get_commands():self.assertLessEqual(len(command.to_dict(bot.bot.tree).get('options',[])),25)

    async def test_kurumi_selector_and_kit_read_do_not_spend_resources(self):
        s=Store(':memory:')
        for uid,key in ((60001,'kurumi'),(60002,'dragon')):
            s.profile(uid)
            with s.db:s.db.execute('INSERT OR IGNORE INTO units VALUES(?,?,1)',(uid,key))
            s.equip(uid,key)
        old=bot.store;bot.store=s
        try:
            i=SimpleNamespace(user=SimpleNamespace(id=60002),response=SimpleNamespace(send_message=AsyncMock(),edit_message=AsyncMock()))
            view=bot.Duel(60001,60002);await view.accept.callback(i)
            view.battle.turn=0;view.battle.pending=[1];view.refresh_buttons()
            self.assertTrue(view.skill.disabled)
            self.assertEqual({o.value for o in view.action_select.options},{'aleph','bet','dalet','zayin','het','yud'})
            before=copy.deepcopy([vars(f) for f in view.battle.fighters])
            await view.kit.callback(i)
            self.assertTrue(i.response.send_message.await_args.kwargs['ephemeral'])
            self.assertEqual(before,[vars(f) for f in view.battle.fighters])
            view.close()
        finally:bot.store=old;s.db.close()
