import os
os.environ['GACHA_DB'] = ':memory:'
import sqlite3
import tempfile
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
import bot
from game import Store, GameError


class RewardTests(unittest.TestCase):
    def setUp(self):
        self.store = Store(':memory:')

    def tearDown(self):
        self.store.db.close()

    def create(self, code='WELCOME', **overrides):
        args = dict(code=code, actor=1, guild=10, gems=500, unit='kuru',
                    copies=2, expires=int(time.time())+3600, max_uses=3)
        args.update(overrides)
        return self.store.create_code(**args)

    def test_rewards_once_across_code_case_and_restart_state(self):
        self.create()
        self.assertEqual(self.store.redeem(2, ' welcome '), (500,'kuru',2))
        self.assertEqual(self.store.profile(2), (1500,0,'knight'))
        self.assertEqual(dict(self.store.collection(2))['kuru'],2)
        with self.assertRaises(GameError): self.store.redeem(2,'WELCOME')
        row=self.store.db.execute('SELECT gems,unit,copies FROM code_claims').fetchone()
        self.assertEqual(row,(500,'kuru',2))
        self.assertEqual(self.store.code_history(10)[0][3],1)

    def test_shared_global_limit(self):
        self.create(max_uses=1)
        self.store.redeem(2,'WELCOME')
        with self.assertRaises(GameError):self.store.redeem(3,'WELCOME')
        self.assertIsNone(self.store.db.execute('SELECT 1 FROM players WHERE id=3').fetchone())

    def test_closed_expired_unknown_and_wrong_guild(self):
        self.create()
        with self.assertRaises(GameError):self.store.close_code('WELCOME',11)
        self.assertEqual(self.store.code_history(11),[])
        self.store.close_code('welcome',10)
        with self.assertRaises(GameError):self.store.redeem(2,'WELCOME')
        with self.assertRaises(GameError):self.create(code='welcome')
        self.create('EXPIRED')
        with self.store.db:self.store.db.execute("UPDATE reward_codes SET expires=100 WHERE code='EXPIRED'")
        with patch('game.time.time',return_value=100):
            with self.assertRaises(GameError):self.store.redeem(2,'EXPIRED')
        with self.assertRaises(GameError):self.store.redeem(2,'UNKNOWN')

    def test_invalid_rewards_rejected_before_writes(self):
        for overrides in [dict(gems=-1),dict(gems=True),dict(gems=0,unit='',copies=0),
                          dict(unit='unknown'),dict(unit='',copies=1),dict(copies=0),
                          dict(copies=1001),dict(expires=0),dict(max_uses=0),dict(max_uses=True)]:
            with self.subTest(overrides=overrides):
                with self.assertRaises(GameError):self.create(**overrides)
        for code in ['ab','x'*33,'สวัสดี','ABC DEF',"x';--"]:
            with self.assertRaises(GameError):self.create(code)
        self.assertEqual(self.store.code_history(10),[])

    def test_gems_only_and_characters_only(self):
        self.create('GEMS',unit='',copies=0)
        self.create('UNITS',gems=0)
        self.store.redeem(2,'GEMS');self.store.redeem(2,'UNITS')
        self.assertEqual(self.store.profile(2)[0],1500)
        self.assertEqual(dict(self.store.collection(2))['kuru'],2)

    def test_failed_audit_rolls_back_rewards_claim_limit_and_new_account(self):
        self.create()
        self.store.db.execute("CREATE TRIGGER fail_claim BEFORE INSERT ON code_claims BEGIN SELECT RAISE(ABORT,'failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):self.store.redeem(2,'WELCOME')
        self.assertEqual(self.store.code_history(10)[0][3],0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM players').fetchone()[0],0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM units').fetchone()[0],0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM code_claims').fetchone()[0],0)

    def test_caps_roll_back_combined_rewards(self):
        self.create()
        self.store.profile(2)
        with self.store.db:self.store.db.execute("INSERT INTO units VALUES(2,'kuru',1000000)")
        with self.assertRaises(GameError):self.store.redeem(2,'WELCOME')
        self.assertEqual(self.store.profile(2)[0],1000)
        self.assertEqual(self.store.code_history(10)[0][3],0)
        with self.store.db:self.store.db.execute('UPDATE players SET gems=1000000000000 WHERE id=2')
        with self.assertRaises(GameError):self.store.redeem(2,'WELCOME')
        self.assertEqual(self.store.code_history(10)[0][3],0)

    def test_counter_failure_rolls_back_claim_and_both_rewards(self):
        self.create()
        self.store.profile(2)
        self.store.db.execute("CREATE TRIGGER fail_counter BEFORE UPDATE ON reward_codes BEGIN SELECT RAISE(ABORT,'failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):self.store.redeem(2,'WELCOME')
        self.assertEqual(self.store.profile(2)[0],1000)
        self.assertNotIn('kuru',dict(self.store.collection(2)))
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM code_claims').fetchone()[0],0)
        self.assertEqual(self.store.code_history(10)[0][3],0)

    def test_old_save_preserved_and_claim_persists(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'save.db'
            old=Store(path)
            old.admin_grant('old',1,10,2,'team')
            old.daily(2,now=86400)
            with old.db:
                old.db.execute("INSERT INTO banner_pity VALUES(2,'kuru',12,3,1)")
                for table in ('reward_codes','code_claims','update_logs'):old.db.execute('DROP TABLE '+table)
            tables=('players','units','squads','banner_pity','admin_audit')
            before={t:old.db.execute('SELECT * FROM '+t).fetchall() for t in tables}
            old.db.close()
            new=Store(path)
            self.assertEqual(before,{t:new.db.execute('SELECT * FROM '+t).fetchall() for t in tables})
            new.create_code('WELCOME',1,10,500,'kuru',1,int(time.time())+1000,10)
            new.redeem(2,'WELCOME');new.publish_update('1.0',1,10,'แรก','รายละเอียด')
            new.db.close()
            reopened=Store(path)
            with self.assertRaises(GameError):reopened.redeem(2,'WELCOME')
            with self.assertRaises(GameError):reopened.publish_update('1.0',1,10,'ซ้ำ','ซ้ำ')
            self.assertEqual(reopened.lineup(2),['kuru','eiji','yuko','mala'])
            self.assertEqual(reopened.guarantees(2,'kuru'),(12,3))
            self.assertTrue(reopened.featured_guaranteed(2,'kuru'))
            self.assertEqual(reopened.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
            reopened.db.close()

    def test_concurrent_redemptions_cannot_exceed_limit_or_claim_twice(self):
        for same_user in (False, True):
            with self.subTest(same_user=same_user), tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'race.db'
                setup=Store(path)
                setup.create_code('RACE',1,10,100,'',0,int(time.time())+1000,1 if not same_user else 10)
                setup.db.close()
                barrier=Barrier(2)
                def claim(uid):
                    store=Store(path)
                    try:
                        barrier.wait(timeout=5)
                        try:store.redeem(uid,'RACE');return True
                        except GameError:return False
                    finally:store.db.close()
                with ThreadPoolExecutor(max_workers=2) as pool:
                    tasks=[pool.submit(claim,2),pool.submit(claim,2 if same_user else 3)]
                    self.assertEqual(sum(t.result(timeout=10) for t in tasks),1)
                final=Store(path)
                self.assertEqual(final.db.execute('SELECT count(*) FROM code_claims').fetchone()[0],1)
                self.assertEqual(final.code_history(10)[0][3],1)
                final.db.close()


class UpdateTests(unittest.TestCase):
    def setUp(self):self.store=Store(':memory:')
    def tearDown(self):self.store.db.close()

    def test_history_details_and_case_insensitive_version_uniqueness(self):
        self.store.publish_update('V1.0',1,10,'ข่าว','เนื้อหา')
        with self.assertRaises(GameError):self.store.publish_update('v1.0',2,11,'ซ้ำ','ซ้ำ')
        self.store.publish_update('v2.0',1,10,'ใหม่','เนื้อหาใหม่')
        self.assertEqual([r[0] for r in self.store.updates()],['v2.0','v1.0'])
        self.assertEqual(self.store.updates('V1.0')[0][2:],('ข่าว','เนื้อหา'))
        self.assertEqual(self.store.updates('missing'),[])
        self.assertEqual(self.store.db.execute('SELECT actor,guild FROM update_logs WHERE version=?',('v1.0',)).fetchone(),(1,10))

    def test_validation_and_latest_five_do_not_delete_history(self):
        for version,title,body in [('bad version','x','y'),('x','','y'),('x','x',' '),('x','a'*101,'x'),('x','x','b'*1801)]:
            with self.assertRaises(GameError):self.store.publish_update(version,1,10,title,body)
        for i in range(7):self.store.publish_update(str(i),1,10,'หัวข้อ','รายละเอียด')
        self.assertEqual(len(self.store.updates()),5)
        self.assertEqual(len(self.store.updates('0')),1)

    def test_concurrent_publish_only_one_version_survives(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'updates.db'
            Store(path).db.close()
            barrier=Barrier(2)
            def publish(version):
                store=Store(path)
                try:
                    barrier.wait(timeout=5)
                    try:store.publish_update(version,1,10,'หัวข้อ','เนื้อหา');return True
                    except GameError:return False
                finally:store.db.close()
            with ThreadPoolExecutor(max_workers=2) as pool:
                tasks=[pool.submit(publish,v) for v in ('V1','v1')]
                self.assertEqual(sum(t.result(timeout=10) for t in tasks),1)
            store=Store(path)
            self.assertEqual(len(store.updates()),1)
            store.db.close()


class RewardCommandTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.store=Store(':memory:')
        self.store_patch=patch.object(bot,'store',self.store);self.store_patch.start()
        self.settings=patch.dict(os.environ,{'ADMIN_GUILD_ID':'10','DISCORD_GUILD_ID':''});self.settings.start()

    def tearDown(self):
        self.settings.stop();self.store_patch.stop();self.store.db.close()

    def interaction(self,admin=True,guild=10):
        return SimpleNamespace(user=SimpleNamespace(id=2),guild_id=guild,
            permissions=bot.discord.Permissions(administrator=admin),response=SimpleNamespace(send_message=AsyncMock(),defer=AsyncMock()),followup=SimpleNamespace(send=AsyncMock()))

    async def test_all_admin_commands_check_permissions_and_trusted_guild(self):
        commands=[(bot.admin_code_create,('HELLO','2099-12-31T23:59:00+07:00',10)),
                  (bot.admin_code_close,('HELLO',)),(bot.admin_codes,()),
                  (bot.admin_update_publish,('v1','title','body'))]
        for command,args in commands:
            for interaction in [self.interaction(False),self.interaction(guild=None),self.interaction(guild=11)]:
                with self.assertRaises(GameError):await command.callback(interaction,*args)
            for check in command.checks:
                with self.assertRaises(bot.app_commands.MissingPermissions):await check(self.interaction(False))
        self.assertEqual(self.store.code_history(10),[])
        self.assertEqual(self.store.updates(),[])

    async def test_code_lifecycle_and_private_rewards(self):
        i=self.interaction()
        await bot.admin_code_create.callback(i,'HELLO','2099-12-31T23:59:00+07:00',10,500,bot.app_commands.Choice(name='Kuru',value='kuru'),2)
        await bot.admin_codes.callback(i)
        await bot.redeem.callback(i,'hello')
        self.assertEqual(self.store.profile(2)[0],1500)
        self.assertTrue(i.response.send_message.await_args.kwargs['ephemeral'])
        with self.assertRaises(GameError):await bot.redeem.callback(i,'HELLO')
        await bot.admin_code_close.callback(i,'HELLO')
        self.assertEqual(self.store.code_history(10)[0][4],0)

    async def test_expiry_requires_explicit_timezone(self):
        for date in ['bad','2099-12-31','2099-12-31T23:59:00','2000-01-01T00:00:00Z']:
            with self.assertRaises(GameError):await bot.admin_code_create.callback(self.interaction(),'HELLO',date,10,500)
        self.assertEqual(self.store.code_history(10),[])

    async def test_publish_and_read_without_duplicate_announcement(self):
        i=self.interaction()
        channel=SimpleNamespace(id=100,send=AsyncMock(return_value=SimpleNamespace(id=101)))
        with patch.object(bot,'resolve_update_channel',return_value=channel):
            await bot.admin_update_publish.callback(i,'V1','หัวข้อ','รายละเอียด')
            i.response.send_message.reset_mock()
            with self.assertRaises(GameError):await bot.admin_update_publish.callback(i,'v1','ซ้ำ','ซ้ำ')
            channel.send.assert_awaited_once()
            i.response.send_message.assert_not_awaited()
        await bot.updates.callback(i,'V1')
        self.assertIn('รายละเอียด',i.response.send_message.await_args.kwargs['embed'].description)
        await bot.updates.callback(i)
        self.assertIn('v1',i.response.send_message.await_args.kwargs['embed'].description)

    async def test_registered_payloads_are_valid_discord_commands(self):
        for command in bot.bot.tree.get_commands():
            payload=command.to_dict(bot.bot.tree)
            self.assertLessEqual(len(payload.get('options',[])),25)
        names={c.name for c in bot.admin.commands}
        self.assertTrue({'code_create','code_close','codes','update_publish'}<=names)
