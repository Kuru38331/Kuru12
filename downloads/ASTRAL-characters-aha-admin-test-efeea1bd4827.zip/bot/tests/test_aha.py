import os
os.environ['GACHA_DB']=':memory:'
import copy
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
import bot
from game import Store,Battle,TeamBattle,GameError,CATALOG,FEATURED

class Fixed:
    def randrange(self,n):return 0
    def random(self):return .99
    def choice(self,items):return items[0]

class AhaTests(unittest.TestCase):
    def setUp(self):self.s=Store(':memory:')
    def tearDown(self):self.s.db.close()
    def battle(self,team=False):
        for uid,units in ((1,['aha','eiji','yuko','mala'] if team else ['aha']),(2,['dragon','knight','mage','paladin'] if team else ['dragon'])):
            self.s.profile(uid)
            with self.s.db:
                for unit in units:self.s.db.execute('INSERT OR IGNORE INTO units VALUES(?,?,1)',(uid,unit))
            self.s.equip(uid,units[0])
            if team:self.s.set_lineup(uid,units)
        b=(TeamBattle if team else Battle)(1,2,self.s,Fixed())
        b.aha_config=copy.deepcopy(b.aha_config)
        return b
    def force(self,b,index):
        b.turn=index;pos=b.order.index(index);b.pending=b.order[pos+1:]+b.order[:pos]
    def hold_instant(self,b):b.aha_config['spd']=0

    def test_admin_grant_only_no_public_banners_or_pools(self):
        self.assertNotIn('aha',FEATURED)
        self.s.admin_grant('aha-test',10,20,30,'character',1,'aha')
        self.assertIn('aha',dict(self.s.collection(30)))
        class Last(Fixed):
            def random(self):return 0
            def choice(self,items):
                self.pool=items;return items[-1]
        for banner in ('standard','kuru','yuko','kurumi','mami'):
            rng=Last();self.s.pull(1,rng,banner)
            self.assertNotIn('aha',rng.pool)
        with self.assertRaises(GameError):self.s.create_code('AHA',1,10,0,'aha',1,4102444800,1)

    def test_emantor_not_automatic_skill_and_skill_requires_sp_before_refund(self):
        b=self.battle(True);self.hold_instant(b);a=b.fighters[0]
        self.assertEqual(set(b.aha_config['elation_skills']),{'aha'})
        b.sp[1]=0
        before=copy.deepcopy((b.aha,b.sp,[vars(f) for f in b.fighters],b.rounds))
        with self.assertRaises(GameError):b.act(1,'skill',1)
        self.assertEqual(before,(b.aha,b.sp,[vars(f) for f in b.fighters],b.rounds))
        b.sp[1]=3;b.act(1,'skill',1)
        self.assertEqual(b.sp[1],3)
        self.assertEqual(b.aha[1]['emanator'],1)
        self.assertNotIn('eiji',b.aha_config['elation_skills'])
        self.force(b,0);a.cooldown=0;b.act(1,'skill',2)
        self.assertEqual(b.sp[1],2)
        self.assertEqual(b.aha[1]['emanator'],2)
        self.assertEqual(b._aha_elation_damage(b.fighters[1],0),28)
        self.assertEqual(b._aha_elation_damage(b.fighters[2],0),33)

    def test_wishpower_only_normal_start_not_skip_or_instant(self):
        b=self.battle(True);self.hold_instant(b)
        b.act(1,'skill',1)
        self.assertEqual(b.aha[1]['wishpower'],0)
        b._aha_turn_start(b.fighters[1]);self.assertEqual(b.aha[1]['wishpower'],1)
        b._aha_instant(1);self.assertEqual(b.aha[1]['wishpower'],1)
        b._aha_after_slot(b.fighters[1],skipped=True)
        self.assertEqual(b.aha[1]['wishpower'],1)

    def test_formula_ignores_atk_certified_banger_and_general_damage_boost(self):
        b=self.battle();a=b.fighters[0]
        base=b._aha_elation_damage(a,20)
        a.attack=99999;a.state.update(banger_value=99999,damage_boost=99999,crit_damage=99999)
        self.assertEqual(b._aha_elation_damage(a,20),base)
        self.assertEqual(base,57)
        self.assertGreater(b._aha_elation_damage(a,40),base)
        b.aha_config['elation_percent']+=20
        self.assertGreater(b._aha_elation_damage(a,20),base)

    def test_snapshot_used_by_each_defined_participant_and_spent_once(self):
        b=self.battle(True);self.hold_instant(b)
        # Explicit test-only registration; never grants skills to every character.
        b.aha_config['elation_skills']['eiji']={'kind':'attack','crit':False}
        b.aha_config['elation_skills']['yuko']={'kind':'attack','crit':False}
        b.aha[1]['punchline']=20
        calls=[]
        original=b._aha_elation_damage
        def record(actor,punchline,base=None):calls.append((actor.unit,punchline));return original(actor,punchline,base)
        b._aha_elation_damage=record
        b._aha_instant(1)
        self.assertEqual(calls,[('eiji',20),('yuko',20)])
        self.assertEqual(b.aha[1]['punchline'],0)
        self.assertEqual(b.aha[1]['last_snapshot'],20)
        for f in b.fighters[:3]:
            self.assertEqual(f.state['banger_value'],20)
            self.assertEqual(f.state['banger_turns'],2)
        self.assertNotIn('banger_value',b.fighters[3].state)

    def test_new_punchline_during_instant_survives_and_recursive_call_is_ignored(self):
        b=self.battle(True);self.hold_instant(b)
        b.aha_config['elation_skills']['eiji']={'kind':'attack','crit':False}
        b.aha[1]['punchline']=20
        original=b._aha_hit;calls=[]
        def nested(*args,**kwargs):
            calls.append(1)
            self.assertEqual(b._aha_instant(1),'')
            b._aha_add_punchline(1,1)
            return original(*args,**kwargs)
        b._aha_hit=nested
        b._aha_instant(1)
        self.assertEqual(b.aha[1]['instant_count'],1)
        self.assertEqual(b.aha[1]['punchline'],len(calls))
        self.assertFalse(b.aha[1]['instant_running'])

    def test_banger_expires_after_two_recipient_turns_and_refresh_not_stack(self):
        b=self.battle();self.hold_instant(b);a=b.fighters[0]
        b.aha[1]['punchline']=10;b._aha_instant(1)
        b._aha_after_slot(a,'guard');self.assertEqual(a.state['banger_turns'],1)
        b.aha[1]['punchline']=20;b._aha_instant(1)
        self.assertEqual((a.state['banger_value'],a.state['banger_turns']),(20,2))
        b._aha_after_slot(a,'guard');b._aha_after_slot(a,skipped=True)
        self.assertEqual(a.state['banger_turns'],0);self.assertNotIn('banger_value',a.state)

    def test_gauge_spd_one_instant_after_full_round_without_new_character_slot(self):
        b=self.battle(True)
        before=[vars(f).copy() for f in b.fighters]
        for actor in b.fighters:b._aha_after_slot(actor,'guard')
        self.assertEqual(b.aha[1]['instant_count'],1)
        self.assertEqual(len(b.fighters),8)
        self.assertEqual(b.rounds,0)
        self.assertEqual(b.aha[1]['gauge'],0)
        self.assertEqual([f.cooldown for f in b.fighters],[f['cooldown'] for f in before])
        b.aha_config['spd']=10000
        b._aha_after_slot(b.fighters[0],'guard')
        self.assertEqual(b.aha[1]['instant_count'],2)  # bounded: no while-loop chain

    def test_fallback_when_all_defined_participants_cannot_act(self):
        b=self.battle();self.hold_instant(b)
        a,t=b.fighters;a.stunned=1;b.aha[1]['punchline']=20
        hp=t.hp;b._aha_instant(1)
        self.assertLess(t.hp,hp);self.assertEqual(a.stunned,1)
        self.assertNotIn('banger_value',a.state)

    def test_true_finisher_uses_only_actual_hp_and_never_itself_or_overkill(self):
        b=self.battle(True);self.hold_instant(b)
        b.aha_config['elation_skills']['eiji']={'kind':'attack','crit':False}
        for f in b.fighters[4:]:f.hp=1
        b._aha_instant(1)
        self.assertTrue(all(f.hp==0 for f in b.fighters[4:]))
        self.assertTrue(b.finished)
        self.assertEqual(b.aha[1]['instant_count'],1)

    def test_positive_finisher_uses_actual_damage_only_and_does_not_add_debt(self):
        b=self.battle(True);self.hold_instant(b)
        b.aha_config['elation_skills']['eiji']={'kind':'attack','crit':False}
        b.aha[1].update({'punchline':20,'global':True})
        before=sum(f.hp for f in b.fighters[4:])
        damage=b._aha_elation_damage(b.fighters[1],20)
        expected=damage*4+(damage*4)*20//100
        b._aha_instant(1)
        self.assertEqual(before-sum(f.hp for f in b.fighters[4:]),expected)
        self.assertTrue(all(f.state.get('elation_debt')==5 for f in b.fighters[4:]))

    def test_elation_does_not_consume_general_next_hit_amplifier(self):
        b=self.battle();self.hold_instant(b);a,t=b.fighters
        t.state['yud']=1;hp=t.hp
        b._aha_hit(a,t,20,'aha_skill',True)
        self.assertEqual(hp-t.hp,20)
        self.assertEqual(t.state['yud'],1)
        hp=t.hp;b._aha_hit(a,t,20,'aha_attack')
        self.assertEqual(hp-t.hp,23)
        self.assertNotIn('yud',t.state)

    def test_admin_trial_aha_can_complete_full_match_without_resource_loops(self):
        b=self.battle(True)
        b.aha[1].update(emanator=0)
        while not b.finished:
            a=b.fighters[b.turn];target=b.enemies()[0];action='attack'
            if a.unit=='aha' and b.aha[1]['wishpower']>=4:action='ultimate'
            elif a.unit=='aha' and not a.cooldown and b.sp[a.uid]>=1:action='skill';target=0
            b.act(a.uid,action,target)
            self.assertTrue(all(0<=value<=5 for value in b.sp.values()))
            self.assertFalse(b.aha[1]['instant_running'])
        self.assertLessEqual(b.rounds,b.limit)
        self.assertGreater(b.aha[1]['instant_count'],0)

    def test_ultimate_budget_wishpower_and_critical_whitelist(self):
        b=self.battle(True);self.hold_instant(b);a=b.fighters[0]
        b.aha[1]['wishpower']=4
        before=sum(f.hp for f in b.fighters[4:]);b.act(1,'ultimate',4)
        lost=before-sum(f.hp for f in b.fighters[4:])
        self.assertEqual(lost,a.attack*2)
        self.assertEqual(b.aha[1]['wishpower'],0)
        self.assertEqual(b.aha[1]['faces'],3)
        self.assertEqual(b.aha[1]['gauge'],20)
        b.aha_config['crit_rate_percent']=100
        t=b.fighters[4];t.hp=t.max_hp;hp=t.hp
        b._aha_hit(a,t,20,'elation_skill')
        self.assertEqual(hp-t.hp,20)
        hp=t.hp;b._aha_hit(a,t,20,'aha_ultimate_bounce')
        self.assertEqual(hp-t.hp,30)

    def test_talent_threshold_once_per_cycle_and_faces_bonus_once_per_normal_skill(self):
        b=self.battle(True);self.hold_instant(b)
        b._aha_add_punchline(1,40);self.assertEqual(b.aha[1]['wishpower'],1)
        b._aha_add_punchline(1,10);self.assertEqual(b.aha[1]['wishpower'],1)
        self.assertTrue(all(f.state.get('aha_crit_bonus')==40 for f in b.fighters[:4]))
        b._aha_instant(1);b._aha_add_punchline(1,40);self.assertEqual(b.aha[1]['wishpower'],2)
        b.aha[1].update(emanator=1,faces=3,punchline=0)
        b._aha_after_slot(b.fighters[1],'skill')
        self.assertEqual(b.aha[1]['punchline'],5)

    def test_elation_debt_does_not_reduce_current_or_max_hp_and_caps_healing(self):
        b=self.battle();self.hold_instant(b);a,t=b.fighters
        b.aha[1]['global']=True
        maximum=t.max_hp
        for _ in range(7):b._aha_hit(a,t,1,'aha_skill',True)
        self.assertEqual(t.max_hp,maximum);self.assertEqual(t.hp,maximum-7)
        self.assertEqual(t.state['elation_debt'],25)
        self.assertEqual(b._restore(t,999),0)
        t.hp=20
        b._restore(t,999);self.assertEqual(t.hp,maximum*75//100)
        b.aha[1]['global']=False;t.state['elation_debt']=0
        b._aha_hit(a,t,1,'aha_skill',True)
        self.assertEqual(t.state['elation_debt'],0)

    def test_technique_and_global_saved_and_locked_at_match_start(self):
        self.s.set_aha_settings(1,True,True)
        b=self.battle(True)
        self.assertEqual(b.aha[1]['instant_count'],1)
        self.assertEqual(b.aha[1]['last_snapshot'],20)
        self.assertTrue(b.aha[1]['global'])
        self.s.set_aha_settings(1,False,False)
        self.assertTrue(b.aha[1]['global'])
        self.assertEqual(len(b.aha_start_notes),1)

class AhaCommandTests(unittest.IsolatedAsyncioTestCase):
    async def test_config_requires_admin_and_busy_lock(self):
        s=Store(':memory:');s.admin_grant('a',1,10,2,'character',1,'aha')
        i=SimpleNamespace(user=SimpleNamespace(id=1),guild_id=10,permissions=bot.discord.Permissions(administrator=True),response=SimpleNamespace(send_message=AsyncMock()))
        member=SimpleNamespace(id=2,guild=SimpleNamespace(id=10),bot=False)
        with patch.object(bot,'store',s),patch.dict(os.environ,{'ADMIN_GUILD_ID':'10','DISCORD_GUILD_ID':''}):
            await bot.admin_aha_config.callback(i,member,True,True)
            self.assertEqual(s.aha_settings(2),(1,1))
            bot.busy.add(2)
            try:
                with self.assertRaises(GameError):await bot.admin_aha_config.callback(i,member,False,False)
            finally:bot.busy.discard(2)
            i.permissions=bot.discord.Permissions.none()
            with self.assertRaises(GameError):await bot.admin_aha_config.callback(i,member,False,False)
        s.db.close()
