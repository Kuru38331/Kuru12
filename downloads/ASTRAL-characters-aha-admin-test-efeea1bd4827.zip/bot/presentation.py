"""Discord-native cards. No network requests or database writes during rendering."""
import discord
from new_characters import NEW_NAMES, KITS
from game import CATALOG, skill_cost, skill_cooldown, banner_is_open, ULTIMATES, FEATURED

PURPLE = 0xA78BFA
GOLD = 0xF5C76B
CYAN = 0x53D7D9
FOOTER = 'ASTRAL • Gacha & Arena'
STYLE = {
    'knight': ('🛡️','เหล็กกล้า','ดาบพิทักษ์'),
    'mage': ('🔮','อาคม','ระเบิดดารา'),
    'ranger': ('🏹','วายุ','ศรพายุ'),
    'paladin': ('✨','แสง','คำพิพากษา'),
    'dragon': ('🐉','เพลิง','ลมหายใจมังกร'),
    'kuru': ('🦋','มืด','ราตรีผีเสื้อ'),
    'eiji': ('📸','ภาพถ่าย','บันทึกแสง'),
    'yuko': ('🌺','บุปผา','ฮิกังบานสะบั้น'),
    'mala': ('🎵','เสียง','คลื่นเสียงประสาน'),
    'aha':('🎭','ปิติสุข/Quantum','แต่งตั้ง Emanator'),
    'ronova':('⚖️','หนี้มรณะ','สัญญา'), 'istaroth':('🍃','สายลม/เวลา','คืนจังหวะ'),
    'rhinedottir':('⚗️','เล่นแร่แปรธาตุ','สิ่งสร้าง'), 'asmoday':('🔲','ห้วงมิติ','ผนึกโล่'),
    'kurumi':('🕰️','เวลา/เงา','Zafkiel'), 'mami':('🎀','ริบบิ้น','Summon Musket'),
}

def unit_label(unit):
    name,stars,_,_ = CATALOG[unit]
    return f'{name} [{stars}★]'+(' · ทดลอง' if unit in NEW_NAMES else '')

def bar(current, maximum, size=10):
    current=max(0,min(current,maximum))
    fill=max(1,round(current/maximum*size)) if current else 0
    return '▰'*fill+'▱'*(size-fill)

def card(title, description='', color=PURPLE):
    embed=discord.Embed(title=title,description=description,color=color)
    embed.set_footer(text=FOOTER)
    return embed

def character_embed(unit):
    name,stars,hp,attack=CATALOG[unit]
    if unit in NEW_NAMES:
        embed=card(f'{name} • 5★ • รุ่นทดลอง',KITS[unit])
        embed.add_field(name='ค่าทดสอบ ยังไม่สมดุลขั้นสุดท้าย',value=f'HP {hp} · ATK {attack} · CD สกิลทั่วไป {skill_cooldown(unit)} เทิร์น')
        embed.add_field(name='ต้นทุน',value='กระสุนใช้ HP/เวลา ไม่ใช้ SP' if unit=='kurumi' else 'สกิล 1 SP · อันติ Wishpower 4 · แอดมินทดลองเท่านั้น' if unit=='aha' else 'สกิล 1 SP · อันติพลัง 100')
        embed.add_field(name='ขอบเขต',value='ชุดท่า C0; ยังไม่มี C1–C6 · Aha มี Global ทดลองเฉพาะหนี้ปิติสุข; ตัวอื่นยังไม่มี Global · ดู experimental_balance.json',inline=False)
        return embed
    icon,element,skill=STYLE[unit]
    embed=card(f'{icon} {name} • {stars}★'+(' LIMITED' if unit in FEATURED else ''),f'ธาตุ{element} · '+('HP-scaling / Stun DPS' if unit=='kuru' else 'นักสู้'))
    embed.add_field(name='ค่าสถานะ',value=f'HP **{hp}** · SP ทีมเริ่ม **3/5**\n'+('ความเสียหายสเกล **HP สูงสุด**' if unit=='kuru' else f'ATK **{attack}**'),inline=False)
    if unit=='kuru':
        embed.add_field(name='🦋 อาวุธ · ผีเสื้อแห่งราตรี',value='ฝูงผีเสื้อเงามืดคือคมอาวุธของ Kuru',inline=False)
        embed.add_field(name='โจมตี · ปีกเงา',value='ดาเมจ **16% HP สูงสุด** (เริ่มต้น 38) · คืน 1 SP',inline=False)
        embed.add_field(name='สกิล · ราตรีผีเสื้อ',value='ดาเมจ **32% HP สูงสุด** (เริ่มต้น 76) + **สตั้น 1 เทิร์น**\nใช้ **1 SP** · เว้น **3 เทิร์นที่ลงมือได้** ก่อนใช้ซ้ำ',inline=False)
        embed.add_field(name='🌘 อันติ · สุริยคราสพันผีเสื้อ',value='ดาเมจ **60% HP สูงสุด** (เริ่มต้น 144) · ใช้พลังอันติ **100** ไม่ใช้ SP\nใช้ได้เฉพาะเทิร์นตัวเอง · ไม่ติดสตั้น · การป้องกันลดดาเมจได้',inline=False)
        embed.add_field(name='เกจอันติ',value='เริ่ม 0/100 ทุกแมตช์ · โจมตี +25 · สกิล +35 · ป้องกัน +15\nถูกโจมตีแล้วเสีย HP +10 · หลังใช้อันติเกจเหลือ 0',inline=False)
        embed.add_field(name='กลไกสตั้น',value='ข้ามเทิร์นเป้าหมายอัตโนมัติ แสดงในบันทึกการต่อสู้\nการป้องกันลดดาเมจได้ แต่ไม่กันสตั้น · ไม่สตั้นเป้าหมายที่แพ้แล้ว',inline=False)
        embed.add_field(name='ได้รับจาก',value='ตู้ **Kuru Limited** เท่านั้น ไม่อยู่ในตู้ถาวร\n5★ มีโอกาส 50% เป็น Kuru / 50% สุ่มพูล Eiji, Ronova, Istaroth, Rhinedottir, Asmoday เท่ากัน ถ้าหลุดเรท 5★ ครั้งถัดไปเป็น Kuru แน่นอน',inline=False)
    elif unit in ('eiji','yuko','mala'):
        details={
            'eiji':('📸 กล้องบันทึกภาพ','บันทึก HP ที่เสียสะสมสูงสุด 90 ใช้สกิลทำดาเมจ 2×ATK + ครึ่งหนึ่งของภาพบันทึก แล้วล้างบันทึก','อันติ: 3×ATK + ภาพบันทึกทั้งหมด แล้วล้างบันทึก · อยู่ในตู้ถาวรและเป็นตัวหลุดเรท'),
            'yuko':('🌺 ดาบและดอกฮิกังบาน','สกิล 2×ATK + แผลฮิกังบาน 2 เทิร์น แผลสร้างดาเมจ 8% HP สูงสุดของเป้าหมายตอนเริ่มเทิร์น ไม่ถูกลดด้วยการป้องกัน','อันติ: 3×ATK + แผลฮิกังบาน 3 เทิร์น · Limited ตู้แยก ไม่อยู่ตู้ถาวร'),
            'mala':('🎵 เสียง ดนตรี และคลื่นเสียง','สกิล 2×ATK พร้อมฮีลเพื่อนที่มีสัดส่วน HP ต่ำที่สุด 12% HP สูงสุดของเพื่อน','อันติ: 3×ATK พร้อมฮีลทุกคนที่ยังมีชีวิตในทีม 18% HP สูงสุดของแต่ละคน · 4★ พูลร่วม')}
        weapon,effect,ultimate=details[unit]
        embed.add_field(name=weapon,value=effect+'\nใช้ 1 SP · เว้น 2 เทิร์น',inline=False)
        embed.add_field(name='🌘 '+ULTIMATES[unit]['name'],value=ultimate+'\nใช้พลัง 100 ไม่ใช้ SP',inline=False)
        embed.add_field(name='พลังอันติ',value='โจมตี +25 · สกิล +35 · ป้องกัน +15 · เสีย HP +10 · เริ่มแมตช์ที่ 0',inline=False)
    else:
        embed.add_field(name=f'สกิล · {skill}',value=f'ดาเมจ {attack*2} · ใช้ 1 SP · เว้น 2 เทิร์น',inline=False)
    return embed

def banner_embed(banner='standard'):
    if banner in FEATURED:
        unit=FEATURED[banner]
        label=CATALOG[unit][0]
        theme=STYLE[unit][0]+' '+label
        embed=card(f'{label.upper()} LIMITED • {theme}',f'**{label} 5★** · ตู้ Limited แยกเฉพาะตัวละคร')
        feature='HP **240** · สกิล **32% HP สูงสุด** + สตั้น 1 เทิร์น\nอันติ **60% HP สูงสุด**' if unit=='kuru' else 'HP **190** · ATK **38** · ดาบและดอกฮิกังบาน\nสกิลและอันติสร้างแผลบุปผาต่อเนื่อง' if unit=='yuko' else KITS[unit]+'\n**ค่าสถานะรุ่นทดลอง ยังไม่ใช่สเปกยืนยัน**'
        embed.add_field(name='✦ ตัวละครประจำตู้',value=feature,inline=False)
        embed.add_field(name='💎 อธิษฐาน',value='**100 เพชร** / 1 ครั้ง · **1,000 เพชร** / 10 ครั้ง',inline=False)
        embed.add_field(name='🎯 50/50 และการันตี',value=f'5★ ภายใน **50 ครั้ง** · 50% **{label}** / 50% **Eiji / Ronova / Istaroth / Rhinedottir / Asmoday**\nถ้าหลุดเรท: 5★ ครั้งถัดไปเป็น **{label} แน่นอน**\n4★ ขึ้นไปภายใน **10 ครั้ง** · ตัวนับและสถานะการันตีแยกแต่ละตู้',inline=False)
        embed.add_field(name='อัตราพื้นฐานก่อนการันตี',value='5★ **2%** / 4★ **10%** / 3★ **88%**\n4★: พาลาดิน / Mala Natsumi โอกาสเท่ากัน',inline=False)
        embed.add_field(name='สถานะตู้',value=('เปิดตู้ · ยังไม่กำหนดวันปิด' if banner_is_open(banner) else 'ปิดตู้แล้ว')+'\nLimited ไม่เข้าตู้ถาวร · รางวัลเป็นของผู้กดเท่านั้น',inline=False)
        embed.set_image(url='attachment://'+(f'{banner}-banner.png' if banner in ('kuru','yuko') else 'summon-banner.png'))
        return embed
    embed=card('✦ ASTRAL SUMMON • พันธสัญญาราชามังกร',
        'เมื่อดวงดาวตอบรับ… ตำนานบทใหม่จะเป็นของคุณ\n'
        'ตู้ถาวร • สะสมตัวละครเพื่อประลองกับเพื่อน')
    embed.add_field(name='👑 ตำนาน 5★',value='**ราชามังกร** · เพลิง\n**Eiji / Ronova / Istaroth / Rhinedottir / Asmoday**\nรวมราชามังกรที่คงไว้ในตู้ถาวร โอกาสเท่ากันเมื่อได้ 5★',inline=True)
    embed.add_field(name='✨ อัศวิน 4★',value='**พาลาดิน** · แสง\n**Mala Natsumi** · เสียง',inline=True)
    embed.add_field(name='💎 เลือกเส้นทางแห่งโชคชะตา',value='**100 เพชร** / 1 ครั้ง　•　**1,000 เพชร** / 10 ครั้ง',inline=False)
    embed.add_field(name='🎯 การันตีที่เดินไปกับคุณ',value='5★ ภายใน **50 ครั้ง** · 4★ ขึ้นไปภายใน **10 ครั้ง**\nนับรวมทั้งสุ่มเดี่ยวและสุ่มสิบ รีเซ็ตเมื่อได้ระดับที่กำหนด',inline=False)
    embed.add_field(name='อัตราพื้นฐานก่อนการันตี',value='5★ **2%**　/　4★ **10%**　/　3★ **88%**\nทุกคนกดได้ · ใช้เพชรและรับตัวละครเข้าบัญชีผู้กดเท่านั้น',inline=False)
    embed.set_image(url='attachment://summon-banner.png')
    return embed

def pity_embed(store, uid, banner='standard'):
    gems,_,_=store.profile(uid)
    pity,pity4=store.guarantees(uid,banner)
    embed=card('🎯 เส้นทางสู่ดวงดาว',f'กระเป๋าของ <@{uid}> · **{gems:,} 💎**\nตู้ **{CATALOG[FEATURED[banner]][0]+" Limited" if banner in FEATURED else "ถาวร"}**')
    embed.add_field(name=f'5★ · {pity}/50',value=f'`{bar(pity,50)}`\nอีกไม่เกิน **{50-pity} ครั้ง**',inline=False)
    embed.add_field(name=f'4★ ขึ้นไป · {pity4}/10',value=f'`{bar(pity4,10)}`\nอีกไม่เกิน **{10-pity4} ครั้ง**',inline=False)
    if banner in FEATURED:
        embed.add_field(name='สถานะ 50/50',value='5★ ถัดไปเป็นตัวประจำตู้แน่นอน' if store.featured_guaranteed(uid,banner) else '5★ ถัดไปลุ้น 50/50 กับพูลหลุดเรท 5 ตัว',inline=False)
    return embed

def result_embed(store, uid, units, banner='standard',payment='gems'):
    top=max(CATALOG[u][1] for u in units)
    gems,_,_=store.profile(uid)
    pity,pity4=store.guarantees(uid,banner)
    spent=f'{len(units)} ตั๋วตัวละคร' if payment=='tickets' else f'{len(units)*100:,} 💎'
    embed=card('✦ ดวงดาวตอบรับคำอธิษฐาน',
        f'ตู้ **{CATALOG[FEATURED[banner]][0]+" Limited" if banner in FEATURED else "ถาวร"}**\nผลสุ่ม **{len(units)} ครั้ง** · ใช้ **{spent}**', GOLD if top==5 else PURPLE if top==4 else CYAN)
    rows=[]
    for index,unit in enumerate(units,1):
        icon,element,_=STYLE[unit]
        stars=CATALOG[unit][1]
        rows.append(f'`{index:02}` {"🌟" if stars==5 else "✦"} **{unit_label(unit)}** {icon} {element}')
    embed.add_field(name='ผู้ร่วมเดินทางคนใหม่',value='\n'.join(rows),inline=False)
    embed.add_field(name='💎 คงเหลือ',value=f'**{gems:,}**',inline=True)
    if payment=='tickets':embed.add_field(name='🎟️ ตั๋วตัวละครคงเหลือ',value=str(store.ticket_balance(uid)[0]),inline=True)
    embed.add_field(name='🎯 การันตี',value=f'5★ `{pity}/50` · 4★+ `{pity4}/10`',inline=True)
    if banner in FEATURED:
        embed.add_field(name='สถานะหลังสุ่ม',value='5★ ถัดไปเป็นตัวประจำตู้แน่นอน' if store.featured_guaranteed(uid,banner) else '5★ ถัดไปลุ้น 50/50 กับพูลหลุดเรท 5 ตัว',inline=False)
    embed.set_footer(text=FOOTER+' • ตัวละครซ้ำสะสมเป็นจำนวนสำเนา')
    return embed

def battle_embed(ids,battle,history=(),ended=None,target_index=None):
    if battle and len(battle.fighters)>2:
        return team_battle_embed(ids,battle,history,ended,target_index)
    if not battle:
        embed=card('⚔️ ARENA • จดหมายท้าประลอง',f'<@{ids[0]}>  **VS**  <@{ids[1]}>\n\nผู้ถูกท้ากด **รับคำท้า** เพื่อเข้าสู่สนาม\nเลือกตัวละครด้วย `/team` ก่อนส่งคำท้า',CYAN)
    else:
        embed=card('⚔️ ASTRAL ARENA • ศึกแห่งดวงดาว',color=GOLD if battle.finished else CYAN)
        for index,fighter in enumerate(battle.fighters):
            _,_,_,attack=CATALOG[fighter.unit]
            maximum=fighter.max_hp
            cost=skill_cost(fighter.unit)
            scaling='HP-scaling 16% / 32%' if fighter.unit=='kuru' else f'ATK **{attack}**'
            icon,element,skill=STYLE[fighter.unit]
            active=not battle.finished and index==battle.turn
            status='🛡️ ตั้งรับ' if fighter.guard else 'พร้อมรบ'
            status+=f' · โล่ {fighter.shield}'
            if fighter.unit=='kurumi':status+=f' · เวลา {fighter.state.get("time",0)}/6'
            if fighter.unit=='aha':
                data=battle.aha[fighter.uid]
                status+=f' · Wishpower {data["wishpower"]} · Punchline {data["punchline"]} · Instant {data["gauge"]:.0f}%'
            if fighter.state.get('banger_turns'):status+=f' · Banger {fighter.state["banger_value"]}/{fighter.state["banger_turns"]} เทิร์น'
            if fighter.unit=='mami':status+=f' · ปืน {fighter.state.get("guns",0)}/3'
            if fighter.state.get('contract'):status+=f' · หนี้ {fighter.state.get("debt",0)}'
            if fighter.bleed:status+=f' · 🌺 แผล {fighter.bleed} เทิร์น'
            if fighter.unit=='eiji':status+=f' · 📸 บันทึก {fighter.recorded}/90'
            skill_state=f'รอ {fighter.cooldown} เทิร์น' if fighter.cooldown else 'พร้อมใช้' if battle.sp[fighter.uid]>=cost else 'SP ไม่พอ'
            cost_text=f'{cost} SP'
            if fighter.unit=='kurumi':
                cost_text='HP + เวลา · เลือกกระสุน'
                skill_state='ต้องมี HP >1 และเวลาตามกระสุน'
            ultimate = ''
            if fighter.unit in ULTIMATES and fighter.unit!='aha':
                ultimate = f'\n\n🌘 **{fighter.energy}/100 พลังอันติ**\n`{bar(fighter.energy,100)}`\n'+('**อันติพร้อมใช้!**' if fighter.energy>=100 else 'สะสมพลังเพื่อปลดปล่อยอันติ')
            embed.add_field(name=f'{"▶ " if active else ""}{icon} {unit_label(fighter.unit)}',
                value=f'<@{fighter.uid}> · {element}\n\n❤️ **{fighter.hp}/{maximum}**\n`{bar(fighter.hp,maximum)}`\n'
                f'💠 **{battle.sp[fighter.uid]}/5 SP ทีม**\n`{bar(battle.sp[fighter.uid],5)}`\n\n{scaling} · {status}\n✦ {skill} · {cost_text} · {skill_state}{ultimate}',inline=True)
        if battle.finished:
            status=f'🏆 ผู้ชนะ <@{battle.winner}>' if battle.winner else '🤝 เสมอ'
        else:
            status=f'🎯 ตาของ <@{battle.fighters[battle.turn].uid}> · เทิร์นที่ {battle.rounds+1}'
        embed.add_field(name='สถานะสนาม',value=status,inline=False)
        if history:
            embed.add_field(name='📜 บันทึกการต่อสู้',value='\n'.join(history[-3:]),inline=False)
        embed.add_field(name='คำสั่งสนามรบ',value='⚔️ โจมตี: คืน 1 SP · 🛡️ ป้องกัน: ลดดาเมจ 50% / ไม่คืน SP\n✦ สกิลทั่วไป: 1 SP / เว้น 2 เทิร์น · Kuru: 1 SP / เว้น 3 เทิร์น + สตั้น 1 เทิร์น\n🌘 อันติ Kuru: ใช้พลัง 100 · ดาเมจ 60% HP สูงสุด · ไม่ใช้ SP',inline=False)
    if battle and getattr(battle,'aha_start_notes',None):embed.add_field(name='Technique ก่อนแมตช์ (เปิดเผยทั้งสองฝ่าย)',value='\n'.join(battle.aha_start_notes),inline=False)
    if ended:
        embed.description=ended
        embed.color=discord.Color.dark_grey()
    embed.set_footer(text=FOOTER+' • หมดเวลาเมื่อไม่มีการเล่น 120 วินาที • สูงสุด 100 เทิร์น')
    return embed


def team_battle_embed(ids,battle,history=(),ended=None,target_index=None):
    embed=card('⚔️ ASTRAL ARENA • 4 VS 4',ended or 'เลือกเป้าหมาย แล้วใช้คำสั่งของตัวละครที่ถึงคิว',GOLD if battle.finished else CYAN)
    for owner in ids:
        rows=[]
        for index,f in enumerate(battle.fighters):
            if f.uid!=owner:continue
            icon=STYLE[f.unit][0]
            active='▶ ' if not battle.finished and index==battle.turn else ''
            status='💀 ล้ม' if not f.hp else ('🛡️' if f.guard else '')
            status+=f' โล่{f.shield}'
            if f.unit=='kurumi':status+=f' เวลา{f.state.get("time",0)}/6'
            if f.unit=='aha':
                data=battle.aha[f.uid]
                status+=f' Wish{data["wishpower"]} Punch{data["punchline"]} Instant{data["gauge"]:.0f}%'
            if f.state.get('banger_turns'):status+=f' Banger{f.state["banger_value"]}/{f.state["banger_turns"]}'
            if f.unit=='mami':status+=f' ปืน{f.state.get("guns",0)}/3'
            if f.state.get('contract'):status+=f' หนี้{f.state.get("debt",0)}'
            if f.stunned:status+=' 💫 สตั้น'
            if f.bleed:status+=f' 🌺{f.bleed}'
            energy=f' · 🌘{f.energy}' if f.unit in ULTIMATES and f.unit!='aha' else ''
            record=f' · 📸{f.recorded}' if f.unit=='eiji' else ''
            rows.append(f'{active}{icon} **{unit_label(f.unit)}** {status}\n❤️ {f.hp}/{f.max_hp} `{bar(f.hp,f.max_hp,7)}`\n💠 {battle.sp[f.uid]}/5 SP ทีม · CD {f.cooldown}{energy}{record}')
        embed.add_field(name=f'ทีมของ <@{owner}>',value='\n\n'.join(rows),inline=True)
    if battle.finished:
        text=f'🏆 ผู้ชนะ <@{battle.winner}>' if battle.winner else '🤝 เสมอ'
    else:
        actor=battle.fighters[battle.turn]
        cost_text='HP + เวลา · เลือกกระสุน' if actor.unit=='kurumi' else f'{skill_cost(actor.unit)} SP'
        text=f'เทิร์น **{battle.rounds+1}** · <@{actor.uid}> ควบคุม **{CATALOG[actor.unit][0]}**\n✦ {STYLE[actor.unit][2]} · {cost_text} · CD {actor.cooldown}'
        if target_index in battle.enemies():text+=f'\n🎯 เป้าหมาย: **{CATALOG[battle.fighters[target_index].unit][0]}**'
    embed.add_field(name='คิวและเป้าหมาย',value=text,inline=False)
    if history:embed.add_field(name='📜 บันทึกล่าสุด',value='\n'.join(history[-3:]),inline=False)
    if getattr(battle,'aha_start_notes',None):embed.add_field(name='Technique ก่อนแมตช์ (เปิดเผยทั้งสองฝ่าย)',value='\n'.join(battle.aha_start_notes),inline=False)
    embed.set_footer(text=FOOTER+' • 4 ตัว/ทีม • หมดเวลา 120 วินาที • สูงสุด 200 เทิร์น')
    return embed
