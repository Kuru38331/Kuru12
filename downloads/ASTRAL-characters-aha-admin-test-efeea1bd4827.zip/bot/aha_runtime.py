"""Bot-only experimental Aha formulas; never presented as official HSR formulas."""
import math

class AhaMechanics:
    def _aha_init(self,config,rng):
        self.aha_config=config
        self.rng=rng
        self.aha={owner:{'punchline':0,'wishpower':0,'gauge':0.0,'emanator':None,'faces':0,
                         'threshold_used':False,'instant_running':False,'last_snapshot':0,
                         'instant_count':0,'refund_round':0,'global':False} for owner in self.owners
                  if any(f.uid==owner and f.unit=='aha' for f in self.fighters)}

    def _aha_apply_settings(self,store):
        self.aha_start_notes=[]
        for owner,data in self.aha.items():
            technique,global_enabled=store.aha_settings(owner)
            data['global']=bool(global_enabled)
            if technique:
                data['punchline']=self.aha_config['technique_start_punchline']
                self.aha_start_notes.append(f'ฝ่าย <@{owner}>: Technique 20 Punchline · '+self._aha_instant(owner))

    def _aha_owner(self,owner):
        return next((f for f in self.fighters if f.uid==owner and f.unit=='aha' and f.hp>0),None)

    def _aha_add_punchline(self,owner,amount,created_for_actor=None):
        if owner not in self.aha or not self._aha_owner(owner):return
        data=self.aha[owner];cfg=self.aha_config
        data['punchline']=min(cfg['punchline_cap'],data['punchline']+max(0,amount))
        if data['punchline']>=cfg['talent_threshold'] and not data['threshold_used']:
            data['threshold_used']=True
            data['wishpower']=min(cfg['wishpower_cap'],data['wishpower']+1)
            for friend in self.fighters:
                if friend.uid==owner and friend.hp>0:
                    friend.state['aha_crit_bonus']=cfg['talent_crit_damage_points']
                    friend.state['aha_crit_turns']=cfg['talent_turns']
                    friend.state['aha_crit_new']=friend is created_for_actor

    def _aha_turn_start(self,actor):
        data=self.aha.get(actor.uid)
        if data and self._aha_owner(actor.uid) and data['emanator']==self.fighters.index(actor):
            data['wishpower']=min(self.aha_config['wishpower_cap'],data['wishpower']+1)

    def _aha_elation_damage(self,actor,punchline,base=None):
        cfg=self.aha_config
        base=cfg['elation_base_per_level'] if base is None else base
        extra=0
        data=self.aha.get(actor.uid)
        if data and data['emanator']==self.fighters.index(actor):extra=cfg['emanator_elation_points']
        # Intentionally no ATK, DMG Boost, crit or Certified Banger inputs.
        return max(0,math.floor(cfg['level']*base*(1+(cfg['elation_percent']+extra)/100)*(1+punchline/cfg['punchline_divisor'])))

    def _aha_hit(self,actor,target,damage,kind,elation_skill=False):
        cfg=self.aha_config
        if kind in cfg['crit_eligible']:
            if self.rng.random()*100<cfg['crit_rate_percent']:
                damage=math.floor(damage*(1+(cfg['crit_damage_percent']+actor.state.get('aha_crit_bonus',0))/100))
        if kind in ('elation_skill','aha_skill','fallback'):
            # General next-hit DMG amplification is excluded from Elation DMG.
            if target.guard:damage//=2
            target.guard=False
            lost=self._damage(target,damage,source=actor)
        else:
            lost=self._strike(actor,target,damage)
        data=self.aha.get(actor.uid)
        if elation_skill and lost and data and data['global']:
            target.state['elation_debt']=min(cfg['debt_cap_percent'],target.state.get('elation_debt',0)+cfg['debt_increment_percent'])
        return lost

    def _aha_instant(self,owner):
        data=self.aha.get(owner);aha=self._aha_owner(owner)
        if not data or not aha or self.finished or data['instant_running']:return ''
        cfg=self.aha_config;data['instant_running']=True
        snapshot=data['punchline'];data['last_snapshot']=snapshot
        # Only explicitly configured skills participate. Emanator is not a skill grant.
        participants=[f for f in self.fighters if f.uid==owner and f.hp>0 and not f.stunned and f.unit in cfg['elation_skills']]
        participants.sort(key=lambda f:f.unit=='aha')
        actual_hp=0
        try:
            for friend in participants:
                enemies=[f for f in self.fighters if f.uid!=owner and f.hp>0]
                if not enemies:break
                definition=cfg['elation_skills'][friend.unit]
                if definition['kind']=='finisher':
                    budget=actual_hp*cfg['finisher_actual_hp_percent']//100
                    base,remainder=divmod(budget,len(enemies))
                    for i,target in enumerate(enemies):
                        # True finisher bypasses guard/shield, not counted into itself or debt.
                        lost=min(target.hp,base+(i<remainder))
                        target.hp-=lost
                        if lost and target.unit!='aha':target.energy=min(100,target.energy+10)
                        if target.unit=='eiji':target.recorded=min(90,target.recorded+lost)
                        self._after_damage(target,lost)
                else:
                    damage=self._aha_elation_damage(friend,snapshot)
                    for target in enemies:actual_hp+=self._aha_hit(friend,target,damage,'elation_skill',True)
                friend.state['banger_value']=snapshot
                friend.state['banger_turns']=cfg['banger_turns']
                friend.state['banger_new']=False
            if not participants:
                enemies=[f for f in self.fighters if f.uid!=owner and f.hp>0]
                for target in enemies:self._aha_hit(aha,target,self._aha_elation_damage(aha,snapshot,cfg['fallback_base_per_level']),'fallback',True)
            # One shared snapshot consumed once at close; points gained during it survive.
            data['punchline']=max(0,data['punchline']-snapshot)
            data['threshold_used']=False
            data['instant_count']+=1
            self._outcome()
            return f'Aha Instant · Punchline {snapshot} · ผู้ร่วม {len(participants)}'
        finally:data['instant_running']=False

    def _aha_after_slot(self,actor,action=None,skipped=False):
        cfg=self.aha_config;notes=[]
        data=self.aha.get(actor.uid)
        if data and self._aha_owner(actor.uid):
            if not skipped and data['emanator']==self.fighters.index(actor):
                normalized='skill' if action in ('prepare','barrage') else action
                if normalized in cfg['punchline_gain']:self._aha_add_punchline(actor.uid,cfg['punchline_gain'][normalized],actor)
                if action in ('skill','prepare','barrage') and data['faces']>0:
                    self._aha_add_punchline(actor.uid,cfg['faces_bonus_punchline'],actor)
            if actor.unit=='aha' and action!='ultimate' and data['faces']>0:data['faces']-=1
        for turns,value,new in (('banger_turns','banger_value','banger_new'),('aha_crit_turns','aha_crit_bonus','aha_crit_new')):
            if actor.state.pop(new,False):continue
            if actor.state.get(turns,0):
                actor.state[turns]-=1
                if not actor.state[turns]:actor.state.pop(value,None)
        # A slot is one fixed slice of field time, including skipped normal slots.
        for owner,team in self.aha.items():
            if not self._aha_owner(owner):continue
            increment=cfg['gauge_full']*cfg['spd']/cfg['normal_slot_spd']/len(self.order)
            team['gauge']+=increment
            if team['gauge']>=cfg['gauge_full']:
                team['gauge']-=cfg['gauge_full']
                notes.append(self._aha_instant(owner))
        return '\n'.join(note for note in notes if note)

    def _aha_action(self,actor,target,action):
        if actor.unit!='aha':return None
        cfg=self.aha_config;data=self.aha[actor.uid]
        if action=='attack':
            self._aha_hit(actor,target,actor.attack,'aha_attack')
            if actor.state.get('banger_turns',0):
                damage=math.floor(cfg['level']*cfg['banger_talent_base_per_level']*(1+actor.state.get('banger_value',0)/cfg['punchline_divisor']))
                if target.hp>0:self._aha_hit(actor,target,damage,'banger_talent')
            return 'Aha โจมตี · Talent จาก Certified Banger (ถ้ามี)'
        if action=='skill':
            data['emanator']=self.fighters.index(target)
            # Emanator buff is represented by one pointer, never stacks or grants skills.
            damage=self._aha_elation_damage(actor,data['punchline'],cfg['skill_base_per_level'])
            for enemy in self.fighters:
                if enemy.uid!=actor.uid and enemy.hp>0:self._aha_hit(actor,enemy,damage,'aha_skill',True)
            # Caller pays SP after execution; refund after that payment via action-end hook.
            actor.state['aha_refund']=data['refund_round']!=self.field_round
            data['refund_round']=self.field_round
            return f'แต่งตั้ง Emanator: {target.unit} · Quantum Elation หมู่'
        if action=='ultimate':
            budget=actor.attack*cfg['ultimate_total_atk_percent']//100
            main=budget*cfg['ultimate_main_share_percent']//100
            enemies=[f for f in self.fighters if f.uid!=actor.uid and f.hp>0]
            share,remainder=divmod(main,len(enemies))
            for i,enemy in enumerate(enemies):self._aha_hit(actor,enemy,share+(i<remainder),'aha_ultimate_main')
            bounce_base,bounce_extra=divmod(budget-main,cfg['ultimate_bounces'])
            for i in range(cfg['ultimate_bounces']):
                enemies=[f for f in self.fighters if f.uid!=actor.uid and f.hp>0]
                if not enemies:break
                enemy=self.rng.choice(enemies)
                self._aha_hit(actor,enemy,bounce_base+(i<bounce_extra),'aha_ultimate_bounce')
            data['wishpower']-=cfg['wishpower_cost']
            data['gauge']+=cfg['gauge_full']*cfg['ultimate_gauge_advance_percent']/100
            data['faces']=cfg['faces_turns']
            return 'Aha อันติ · Wishpower 4 · หมู่ + สุ่ม 5 ครั้ง (แบ่งงบรวม)'
        return None
