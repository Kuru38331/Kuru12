import json
import os
import random
import re
import sqlite3
import time
from pathlib import Path
from dataclasses import dataclass, field
from aha_runtime import AhaMechanics
from new_characters import CharacterMechanics, NEW_NAMES, BULLETS

CATALOG = {
    'knight': ('อัศวิน', 3, 140, 24),
    'mage': ('จอมเวท', 3, 100, 34),
    'ranger': ('นักธนู', 3, 120, 32),
    'paladin': ('พาลาดิน', 4, 170, 33),
    'dragon': ('ราชามังกร', 5, 180, 42),
    'kuru': ('Kuru', 5, 240, 0),
    'eiji': ('Eiji', 5, 170, 30),
    'yuko': ('Yuko Hanaka', 5, 190, 38),
    'mala': ('Mala Natsumi', 4, 155, 25),
}

EXPERIMENTAL_BALANCE=json.loads(Path(__file__).with_name('experimental_balance.json').read_text(encoding='utf-8'))
for key,(hp,attack) in EXPERIMENTAL_BALANCE['stats'].items():
    CATALOG[key]=(NEW_NAMES[key],5,hp,attack)

OFF_RATE=('eiji','ronova','istaroth','rhinedottir','asmoday')
BANNERS = ('standard','kuru','yuko','kurumi','mami')
FEATURED = {'kuru':'kuru','yuko':'yuko','kurumi':'kurumi','mami':'mami'}
ULTIMATES = {'kuru': {'name':'สุริยคราสพันผีเสื้อ','hp_percent':60,'energy_cost':100},
    'eiji': {'name':'นิทรรศการความทรงจำ','attack_multiplier':3,'energy_cost':100},
    'yuko': {'name':'สวนบุปผาส่งวิญญาณ','attack_multiplier':3,'energy_cost':100},
    'mala': {'name':'ซิมโฟนีคลื่นเสียง','attack_multiplier':3,'energy_cost':100}}

for key in EXPERIMENTAL_BALANCE['stats']:
    ULTIMATES[key]={'name':'อันติ '+NEW_NAMES[key],'energy_cost':100}

def banner_is_open(banner):
    return banner == 'standard' or os.getenv(banner.upper()+'_BANNER_OPEN','true').lower() not in ('false','0','no')

def skill_cost(unit):
    return 1

def skill_cooldown(unit):
    return 3 if unit == 'kuru' else 0 if unit in ('kurumi','mami') else EXPERIMENTAL_BALANCE['aha']['skill_cooldown'] if unit=='aha' else EXPERIMENTAL_BALANCE['new_skill_cooldown'] if unit in NEW_NAMES else 2

class GameError(Exception):
    pass

class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY, gems INTEGER NOT NULL DEFAULT 1000, daily INTEGER NOT NULL DEFAULT -1, pity INTEGER NOT NULL DEFAULT 0, active TEXT NOT NULL DEFAULT 'knight');
        CREATE TABLE IF NOT EXISTS units(player INTEGER, unit TEXT, copies INTEGER NOT NULL, PRIMARY KEY(player,unit));
        CREATE TABLE IF NOT EXISTS admin_audit(request TEXT PRIMARY KEY, time INTEGER NOT NULL, actor INTEGER NOT NULL, guild INTEGER NOT NULL, target INTEGER NOT NULL, action TEXT NOT NULL, item TEXT NOT NULL, amount INTEGER NOT NULL, reason TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS squads(player INTEGER PRIMARY KEY, units TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS banner_pity(player INTEGER, banner TEXT, pity INTEGER NOT NULL DEFAULT 0, pity4 INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(player,banner));
        CREATE TABLE IF NOT EXISTS reward_codes(code TEXT PRIMARY KEY, guild INTEGER NOT NULL, actor INTEGER NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, max_uses INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1, gems INTEGER NOT NULL, unit TEXT NOT NULL, copies INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS code_claims(code TEXT NOT NULL, player INTEGER NOT NULL, time INTEGER NOT NULL, gems INTEGER NOT NULL, unit TEXT NOT NULL, copies INTEGER NOT NULL, PRIMARY KEY(code,player));
        CREATE TABLE IF NOT EXISTS update_logs(version TEXT PRIMARY KEY, guild INTEGER NOT NULL, actor INTEGER NOT NULL, published INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS aha_settings(player INTEGER PRIMARY KEY, technique INTEGER NOT NULL DEFAULT 0, global_enabled INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS ticket_wallet(player INTEGER PRIMARY KEY, character_tickets INTEGER NOT NULL DEFAULT 0, skin_tickets INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS guild_settings(guild INTEGER PRIMARY KEY, update_channel INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS update_deliveries(version TEXT NOT NULL, guild INTEGER NOT NULL, channel INTEGER NOT NULL, state TEXT NOT NULL, message INTEGER, PRIMARY KEY(version,guild));
        ''')
        # Additive migration from the previous redeem implementation; never rebuild saves.
        for table in ('reward_codes','code_claims'):
            columns={row[1] for row in self.db.execute('PRAGMA table_info('+table+')')}
            with self.db:
                for name in ('character_tickets','skin_tickets'):
                    if name not in columns:
                        self.db.execute('ALTER TABLE '+table+' ADD COLUMN '+name+' INTEGER NOT NULL DEFAULT 0')
        columns = {row[1] for row in self.db.execute('PRAGMA table_info(players)')}
        if 'pity4' not in columns:
            with self.db:
                self.db.execute('ALTER TABLE players ADD COLUMN pity4 INTEGER NOT NULL DEFAULT 0')

        banner_columns = {row[1] for row in self.db.execute('PRAGMA table_info(banner_pity)')}
        if 'featured' not in banner_columns:
            with self.db:
                self.db.execute('ALTER TABLE banner_pity ADD COLUMN featured INTEGER NOT NULL DEFAULT 0')
                # Honor the previous version's promised Kuru on existing banner saves.
                self.db.execute("UPDATE banner_pity SET featured=1 WHERE banner='kuru'")

    def ensure(self, uid):
        self.db.execute('INSERT OR IGNORE INTO players(id) VALUES(?)', (uid,))
        self.db.execute("INSERT OR IGNORE INTO units VALUES(?,'knight',1)", (uid,))

    def profile(self, uid):
        with self.db:
            self.ensure(uid)
        return self.db.execute('SELECT gems,pity,active FROM players WHERE id=?', (uid,)).fetchone()

    def collection(self, uid):
        self.profile(uid)
        return self.db.execute('SELECT unit,copies FROM units WHERE player=? ORDER BY unit', (uid,)).fetchall()

    def daily(self, uid, now=None):
        day = int(time.time() if now is None else now)//86400
        with self.db:
            self.ensure(uid)
            if not self.db.execute('UPDATE players SET gems=gems+300,daily=? WHERE id=? AND daily<?', (day,uid,day)).rowcount:
                raise GameError('รับรางวัลวันนี้แล้ว กลับมาใหม่หลัง 07:00 น. เวลาไทย')
        return 300

    def guarantees(self, uid, banner='standard'):
        self.profile(uid)
        if banner not in BANNERS:
            raise GameError('ไม่พบตู้กาชานี้')
        if banner == 'standard':
            return self.db.execute('SELECT pity,pity4 FROM players WHERE id=?',(uid,)).fetchone()
        row = self.db.execute('SELECT pity,pity4 FROM banner_pity WHERE player=? AND banner=?',(uid,banner)).fetchone()
        return row or (0,0)

    def featured_guaranteed(self,uid,banner):
        if banner not in FEATURED:
            return False
        row=self.db.execute('SELECT featured FROM banner_pity WHERE player=? AND banner=?',(uid,banner)).fetchone()
        return bool(row and row[0])

    def set_lineup(self,uid,units):
        if len(units)!=4 or len(set(units))!=4 or any(unit not in CATALOG for unit in units):
            raise GameError('ทีม 4v4 ต้องมีตัวละครที่ไม่ซ้ำกัน 4 ตัว')
        with self.db:
            self.ensure(uid)
            owned={row[0] for row in self.db.execute('SELECT unit FROM units WHERE player=?',(uid,))}
            if not set(units)<=owned:
                raise GameError('จัดทีมได้เฉพาะตัวละครที่คุณเป็นเจ้าของ')
            self.db.execute('INSERT INTO squads VALUES(?,?) ON CONFLICT(player) DO UPDATE SET units=excluded.units',(uid,json.dumps(units)))

    def lineup(self,uid):
        row=self.db.execute('SELECT units FROM squads WHERE player=?',(uid,)).fetchone()
        if not row:
            raise GameError('ยังไม่ได้จัดทีม 4 ตัว ใช้ /squad ก่อนท้า 4v4')
        units=json.loads(row[0])
        owned={unit for unit,_ in self.collection(uid)}
        if len(units)!=4 or len(set(units))!=4 or not set(units)<=owned or not set(units)<=CATALOG.keys():
            raise GameError('ทีมไม่สมบูรณ์ กรุณาจัดทีมด้วย /squad ใหม่')
        return units

    def pull(self, uid, rng=random, banner='standard'):
        return self.pull_many(uid,1,rng,banner=banner)[0]

    def pull_many(self, uid, count, rng=random, banner='standard',payment='gems'):
        if type(count) is not int or count not in (1,10):
            raise GameError('เลือกสุ่มได้ครั้งละ 1 หรือ 10 ครั้ง')
        if banner not in BANNERS:
            raise GameError('ไม่พบตู้กาชานี้')
        if not banner_is_open(banner):
            raise GameError('ตู้ Limited นี้ปิดแล้ว เพชรยังอยู่ครบ')
        if payment not in ('gems','tickets'):
            raise GameError('เลือกชำระด้วยเพชรหรือตั๋วตัวละคร')
        with self.db:
            self.ensure(uid)
            gems,pity,pity4 = self.db.execute('SELECT gems,pity,pity4 FROM players WHERE id=?',(uid,)).fetchone()
            if banner != 'standard':
                self.db.execute('INSERT OR IGNORE INTO banner_pity(player,banner) VALUES(?,?)',(uid,banner))
                pity,pity4 = self.db.execute('SELECT pity,pity4 FROM banner_pity WHERE player=? AND banner=?',(uid,banner)).fetchone()
            featured=self.featured_guaranteed(uid,banner)
            if payment=='tickets':
                self.db.execute('INSERT OR IGNORE INTO ticket_wallet(player) VALUES(?)',(uid,))
                if not self.db.execute('UPDATE ticket_wallet SET character_tickets=character_tickets-? WHERE player=? AND character_tickets>=?',(count,uid,count)).rowcount:
                    raise GameError(f'ตั๋วตัวละครไม่พอ ต้องใช้ {count} ใบ ไม่หักเพชรแทน')
            if payment=='gems' and gems < count*100:
                raise GameError(f'เพชรไม่พอ ต้องใช้ {count*100:,} เพชร ลองรับ /daily ก่อน')
            cost=count*100 if payment=='gems' else 0
            units = []
            for _ in range(count):
                roll = rng.random()
                rarity = 5 if pity >= 49 or roll < .02 else 4 if pity4 >= 9 or roll < .12 else 3
                pool = [k for k,v in CATALOG.items() if v[1] == rarity and k not in FEATURED and k!='aha']
                if banner in FEATURED and rarity == 5:
                    won = featured or rng.random()<.5
                    pool = [FEATURED[banner]] if won else list(OFF_RATE)
                    featured = not won
                unit = rng.choice(pool)
                pity = 0 if rarity == 5 else pity+1
                pity4 = 0 if rarity >= 4 else pity4+1
                self.db.execute('INSERT INTO units VALUES(?,?,1) ON CONFLICT(player,unit) DO UPDATE SET copies=copies+1',(uid,unit))
                units.append(unit)
            if banner == 'standard':
                self.db.execute('UPDATE players SET gems=gems-?,pity=?,pity4=? WHERE id=?',(cost,pity,pity4,uid))
            else:
                self.db.execute('UPDATE players SET gems=gems-? WHERE id=?',(cost,uid))
                self.db.execute('UPDATE banner_pity SET pity=?,pity4=?,featured=? WHERE player=? AND banner=?',(pity,pity4,int(featured),uid,banner))
        return units

    def admin_grant(self,request,actor,guild,target,action,amount=1,item='',reason='แอดมินแจกของ'):
        if action not in ('gems','character','team'):
            raise GameError('ประเภทของไม่ถูกต้อง')
        limit=1_000_000_000 if action=='gems' else 1000 if action=='character' else 1
        if type(amount) is not int or not 1<=amount<=limit:
            raise GameError(f'จำนวนต้องอยู่ระหว่าง 1 ถึง {limit:,}')
        if action=='character' and item not in CATALOG:
            raise GameError('ไม่พบตัวละครนี้')
        if not isinstance(reason,str) or len(reason)>200:
            raise GameError('เหตุผลยาวได้ไม่เกิน 200 ตัวอักษร')
        if action=='team':item='kuru,eiji,yuko,mala'
        if action=='gems':item='gems'
        with self.db:
            if self.db.execute('SELECT 1 FROM admin_audit WHERE request=?',(str(request),)).fetchone():
                raise GameError('คำสั่งนี้ดำเนินการแล้ว ไม่เพิ่มของซ้ำ')
            self.ensure(target)
            if action=='gems':
                balance=self.db.execute('SELECT gems FROM players WHERE id=?',(target,)).fetchone()[0]
                if balance+amount>1_000_000_000_000:
                    raise GameError('ยอดเพชรรวมเกินเพดาน 1 ล้านล้าน')
                self.db.execute('UPDATE players SET gems=gems+? WHERE id=?',(amount,target))
            else:
                units=['kuru','eiji','yuko','mala'] if action=='team' else [item]
                for unit in units:
                    count=self.db.execute('SELECT copies FROM units WHERE player=? AND unit=?',(target,unit)).fetchone()
                    if (count[0] if count else 0)+amount>1_000_000:
                        raise GameError('จำนวนสำเนาตัวละครเกินเพดาน')
                    self.db.execute('INSERT INTO units VALUES(?,?,?) ON CONFLICT(player,unit) DO UPDATE SET copies=copies+excluded.copies',(target,unit,amount))
                if action=='team':
                    self.db.execute('UPDATE players SET active=? WHERE id=?',('kuru',target))
                    self.db.execute('INSERT INTO squads VALUES(?,?) ON CONFLICT(player) DO UPDATE SET units=excluded.units',(target,json.dumps(units)))
            self.db.execute('INSERT INTO admin_audit VALUES(?,?,?,?,?,?,?,?,?)',(str(request),int(time.time()),actor,guild,target,action,item,amount,reason))

    def admin_history(self,guild):
        return self.db.execute('SELECT time,actor,target,action,item,amount FROM admin_audit WHERE guild=? ORDER BY time DESC,rowid DESC LIMIT 10',(guild,)).fetchall()

    def equip(self, uid, unit):
        with self.db:
            self.ensure(uid)
            if not self.db.execute('SELECT 1 FROM units WHERE player=? AND unit=?',(uid,unit)).fetchone():
                raise GameError('ยังไม่มีตัวละครนี้')
            self.db.execute('UPDATE players SET active=? WHERE id=?',(unit,uid))

    @staticmethod
    def normalize_code(code):
        if not isinstance(code,str) or not re.fullmatch(r'[A-Za-z0-9_-]{3,32}',code.strip()):
            raise GameError('โค้ดต้องเป็น A-Z, 0-9, _ หรือ - ยาว 3–32 ตัว')
        return code.strip().upper()

    def create_code(self,code,actor,guild,gems,unit,copies,expires,max_uses,character_tickets=0,skin_tickets=0):
        code=self.normalize_code(code)
        if type(gems) is not int or not 0<=gems<=1_000_000_000:
            raise GameError('เพชรต้องอยู่ระหว่าง 0 ถึง 1,000,000,000')
        if unit=='aha':raise GameError('Aha ให้แอดมินแจกทดลองโดยตรงเท่านั้น ยังใช้เป็นรางวัลโค้ดไม่ได้')
        if (unit and unit not in CATALOG) or type(copies) is not int or not 0<=copies<=1000 or bool(unit)!=bool(copies):
            raise GameError('เลือกตัวละครพร้อมจำนวนสำเนา 1–1,000 หรือไม่เลือกทั้งคู่')
        if any(type(n) is not int or not 0<=n<=1_000_000 for n in (character_tickets,skin_tickets)):
            raise GameError('ตั๋วแต่ละชนิดต้องอยู่ระหว่าง 0 ถึง 1,000,000')
        if not gems and not unit and not character_tickets and not skin_tickets:
            raise GameError('ต้องกำหนดรางวัลอย่างน้อยหนึ่งอย่าง')
        if type(expires) is not int or expires<=int(time.time()):
            raise GameError('วันหมดอายุต้องอยู่ในอนาคต')
        if type(max_uses) is not int or not 1<=max_uses<=1_000_000_000:
            raise GameError('สิทธิ์รวมต้องอยู่ระหว่าง 1 ถึง 1,000,000,000')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            if self.db.execute('SELECT 1 FROM reward_codes WHERE code=?',(code,)).fetchone():
                raise GameError('มีโค้ดนี้แล้ว ไม่สามารถสร้างทับหรือเปิดรับซ้ำ')
            self.db.execute('INSERT INTO reward_codes(code,guild,actor,created,expires,max_uses,gems,unit,copies,character_tickets,skin_tickets) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                            (code,guild,actor,int(time.time()),expires,max_uses,gems,unit,copies,character_tickets,skin_tickets))
        return code

    def close_code(self,code,guild):
        code=self.normalize_code(code)
        with self.db:
            if not self.db.execute('UPDATE reward_codes SET enabled=0 WHERE code=? AND guild=?',(code,guild)).rowcount:
                raise GameError('ไม่พบโค้ดของเซิร์ฟเวอร์นี้')

    def code_history(self,guild,code=None):
        fields='code,expires,max_uses,used,enabled,gems,unit,copies'
        if code is not None:
            return self.db.execute(f'SELECT {fields} FROM reward_codes WHERE guild=? AND code=?',(guild,self.normalize_code(code))).fetchall()
        return self.db.execute(f'SELECT {fields} FROM reward_codes WHERE guild=? ORDER BY rowid DESC LIMIT 10',(guild,)).fetchall()

    def redeem(self,uid,code):
        code=self.normalize_code(code)
        # Acquire the write lock BEFORE reading limits, including across connections.
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row=self.db.execute('SELECT expires,max_uses,used,enabled,gems,unit,copies FROM reward_codes WHERE code=?',(code,)).fetchone()
            if not row:raise GameError('ไม่พบโค้ดนี้')
            expires,limit,used,enabled,gems,unit,copies=row
            now=int(time.time())
            if not enabled or now>=expires:raise GameError('โค้ดปิดหรือหมดอายุแล้ว')
            if self.db.execute('SELECT 1 FROM code_claims WHERE code=? AND player=?',(code,uid)).fetchone():
                raise GameError('บัญชีนี้รับโค้ดนี้แล้ว')
            if used>=limit:raise GameError('สิทธิ์ของโค้ดหมดแล้ว')
            self.ensure(uid)
            balance=self.db.execute('SELECT gems FROM players WHERE id=?',(uid,)).fetchone()[0]
            if balance+gems>1_000_000_000_000:raise GameError('ยอดเพชรรวมเกินเพดาน')
            self.db.execute('UPDATE players SET gems=gems+? WHERE id=?',(gems,uid))
            if unit:
                owned=self.db.execute('SELECT copies FROM units WHERE player=? AND unit=?',(uid,unit)).fetchone()
                if (owned[0] if owned else 0)+copies>1_000_000:raise GameError('จำนวนสำเนาตัวละครเกินเพดาน')
                self.db.execute('INSERT INTO units VALUES(?,?,?) ON CONFLICT(player,unit) DO UPDATE SET copies=copies+excluded.copies',(uid,unit,copies))
            tickets=self.db.execute('SELECT character_tickets,skin_tickets FROM reward_codes WHERE code=?',(code,)).fetchone()
            self.db.execute('INSERT OR IGNORE INTO ticket_wallet(player) VALUES(?)',(uid,))
            balance=self.db.execute('SELECT character_tickets,skin_tickets FROM ticket_wallet WHERE player=?',(uid,)).fetchone()
            if any(a+b>1_000_000_000 for a,b in zip(balance,tickets)):
                raise GameError('ยอดตั๋วเกินเพดาน 1,000,000,000')
            self.db.execute('UPDATE ticket_wallet SET character_tickets=character_tickets+?,skin_tickets=skin_tickets+? WHERE player=?',(*tickets,uid))
            self.db.execute('INSERT INTO code_claims(code,player,time,gems,unit,copies,character_tickets,skin_tickets) VALUES(?,?,?,?,?,?,?,?)',(code,uid,now,gems,unit,copies,*tickets))
            self.db.execute('UPDATE reward_codes SET used=used+1 WHERE code=?',(code,))
        return gems,unit,copies

    def set_aha_settings(self,uid,technique,global_enabled):
        with self.db:
            self.db.execute('INSERT INTO aha_settings VALUES(?,?,?) ON CONFLICT(player) DO UPDATE SET technique=excluded.technique,global_enabled=excluded.global_enabled',(uid,int(technique),int(global_enabled)))

    def aha_settings(self,uid):
        return self.db.execute('SELECT technique,global_enabled FROM aha_settings WHERE player=?',(uid,)).fetchone() or (0,0)

    def ticket_balance(self,uid):
        return self.db.execute('SELECT character_tickets,skin_tickets FROM ticket_wallet WHERE player=?',(uid,)).fetchone() or (0,0)

    def code_tickets(self,code):
        return self.db.execute('SELECT character_tickets,skin_tickets FROM reward_codes WHERE code=?',(self.normalize_code(code),)).fetchone() or (0,0)

    def set_update_channel(self,guild,channel):
        with self.db:
            self.db.execute('INSERT INTO guild_settings VALUES(?,?) ON CONFLICT(guild) DO UPDATE SET update_channel=excluded.update_channel',(guild,channel))

    def update_channel(self,guild):
        row=self.db.execute('SELECT update_channel FROM guild_settings WHERE guild=?',(guild,)).fetchone()
        return row[0] if row else None

    def reserve_update_delivery(self,version,guild,channel):
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            if not self.db.execute('SELECT 1 FROM update_logs WHERE version=?',(version.lower(),)).fetchone():
                raise GameError('ไม่พบเวอร์ชันนี้')
            if self.db.execute('SELECT 1 FROM update_deliveries WHERE version=? AND guild=?',(version.lower(),guild)).fetchone():
                raise GameError('เวอร์ชันนี้ส่งหรือเริ่มส่งแล้ว ไม่ส่งซ้ำ ตรวจประวัติการประกาศ')
            self.db.execute('INSERT INTO update_deliveries(version,guild,channel,state) VALUES(?,?,?,?)',(version.lower(),guild,channel,'sending'))

    def finish_update_delivery(self,version,guild,message=None):
        with self.db:
            self.db.execute('UPDATE update_deliveries SET state=?,message=? WHERE version=? AND guild=?',('sent' if message is not None else 'uncertain',message,version.lower(),guild))

    def delivery_history(self,guild):
        return self.db.execute('SELECT version,channel,state,message FROM update_deliveries WHERE guild=? ORDER BY rowid DESC LIMIT 10',(guild,)).fetchall()

    def publish_update(self,version,actor,guild,title,body):
        if not isinstance(version,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,31}',version):
            raise GameError('เวอร์ชันต้องเป็นตัวอักษร/ตัวเลข . _ - ยาว 1–32 ตัว')
        version=version.lower()
        if not isinstance(title,str) or not 1<=len(title.strip())<=100 or not isinstance(body,str) or not 1<=len(body.strip())<=1800:
            raise GameError('หัวข้อยาว 1–100 และรายละเอียด 1–1,800 ตัวอักษร')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            if self.db.execute('SELECT 1 FROM update_logs WHERE version=?',(version,)).fetchone():
                raise GameError('เผยแพร่เวอร์ชันนี้แล้ว ไม่ประกาศซ้ำ')
            self.db.execute('INSERT INTO update_logs VALUES(?,?,?,?,?,?)',(version,guild,actor,int(time.time()),title.strip(),body.strip()))
        return version

    def updates(self,version=None):
        if version is not None:
            return self.db.execute('SELECT version,published,title,body FROM update_logs WHERE version=?',(version.lower(),)).fetchall()
        return self.db.execute('SELECT version,published,title,body FROM update_logs ORDER BY rowid DESC LIMIT 5').fetchall()

@dataclass
class Fighter:
    uid: int
    unit: str
    hp: int
    attack: int
    guard: bool = False
    cooldown: int = 0
    max_hp: int = 0
    stunned: int = 0
    energy: int = 0
    recorded: int = 0
    bleed: int = 0
    bleed_damage: int = 0
    shield: int = 0
    state: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.max_hp == 0:
            self.max_hp = self.hp

class Battle(CharacterMechanics,AhaMechanics):
    def __init__(self, first, second, store, rng=random):
        self._initialize(first,second,[[store.profile(uid)[2]] for uid in (first,second)],rng)
        self._aha_apply_settings(store)

    def _initialize(self,first,second,lineups,rng):
        if first==second:
            raise GameError('ท้าตัวเองไม่ได้')
        self.owners=(first,second)
        self.fighters=[]
        for uid,units in zip(self.owners,lineups):
            for unit in units:
                _,_,hp,attack=CATALOG[unit]
                self.fighters.append(Fighter(uid,unit,hp,attack))
        size=len(lineups[0])
        starting_side=rng.randrange(2)
        self.order=[slot+size*side for slot in range(size) for side in (starting_side,1-starting_side)]
        self.turn=self.order[0]
        self.pending=list(self.order[1:])
        self.field_round=1
        self.finished=False
        self.winner=None
        self.rounds=0
        self.sp={first:3,second:3}
        self.limit=100 if size==1 else 200
        self._aha_init(EXPERIMENTAL_BALANCE['aha'],rng)
        self.last_action=None

    def enemies(self):
        actor=self.fighters[self.turn]
        return [i for i,fighter in enumerate(self.fighters) if fighter.uid!=actor.uid and fighter.hp>0]

    def _outcome(self):
        alive={f.uid for f in self.fighters if f.hp>0}
        if len(alive)<=1:
            self.finished=True
            self.winner=next(iter(alive),None)
        elif self.rounds>=self.limit:
            self.finished=True
        return self.finished

    def _damage(self,target,damage,source=None,dot=False):
        damage=self._new_damage(target,max(0,damage),source,dot)
        lost=min(target.hp,max(0,damage))
        target.hp-=lost
        if lost and target.unit in ULTIMATES and target.unit!='aha':
            target.energy=min(100,target.energy+10)
        if target.unit=='eiji':
            target.recorded=min(90,target.recorded+lost)
        self._after_damage(target,lost)
        return lost

    def _heal(self,actor,percent,allies=False):
        team=[f for f in self.fighters if f.uid==actor.uid and f.hp>0]
        targets=team if allies else [min(team,key=lambda f:f.hp/f.max_hp)]
        healed=0
        for fighter in targets:
            amount=min(fighter.max_hp-fighter.hp,max(1,fighter.max_hp*percent//100))
            healed+=self._restore(fighter,amount)
        return healed

    def _advance(self):
        notes=[]
        self._new_turn_end(self.fighters[self.turn])
        instant=self._aha_after_slot(self.fighters[self.turn],self.last_action)
        if instant:notes.append(instant)
        while not self.finished:
            if not self.pending:
                self.pending=list(self.order)
                self.field_round+=1
            index=self.pending.pop(0)
            fighter=self.fighters[index]
            if fighter.hp<=0:
                continue
            if fighter.bleed:
                fighter.bleed-=1
                lost=self._damage(fighter,fighter.bleed_damage,dot=True)
                notes.append(f'🌺 {CATALOG[fighter.unit][0]} เสีย {lost} HP จากฮิกังบาน')
                if self._outcome():break
                if fighter.hp<=0:continue
            if fighter.stunned:
                fighter.stunned-=1
                fighter.guard=False
                self.rounds+=1
                notes.append(f'🦋 สตั้น: {CATALOG[fighter.unit][0]} ข้าม 1 เทิร์น!')
                self._new_turn_end(fighter,skipped=True)
                instant=self._aha_after_slot(fighter,skipped=True)
                if instant:notes.append(instant)
                if self._outcome():break
                continue
            self.turn=index
            self._aha_turn_start(fighter)
            break
        return '\n'.join(notes)

    def act(self,uid,action,target_index=None,shot_targets=None):
        if self.finished:raise GameError('การต่อสู้จบแล้ว')
        actor=self.fighters[self.turn]
        if actor.uid!=uid:raise GameError('ยังไม่ถึงตาของคุณ')
        if action not in ('attack','skill','ultimate','guard','surrender','prepare','barrage')+BULLETS:
            raise GameError('คำสั่งไม่ถูกต้อง')
        enemies=self.enemies()
        if action in ('guard','surrender'):target_index=enemies[0]
        if target_index is None:
            allies=[i for i,f in enumerate(self.fighters) if f.uid==uid and f.hp>0 and (f is not actor or actor.unit in ('rhinedottir','aha') or action in ('dalet','het'))]
            friendly=action in ('aleph','dalet','het') or (action=='skill' and actor.unit in ('istaroth','rhinedottir','aha'))
            if friendly and not allies:raise GameError('ไม่มีเพื่อนร่วมทีมที่เลือกได้')
            target_index=(allies if friendly else enemies)[0]
        if actor.unit in NEW_NAMES or action in BULLETS+('prepare','barrage'):
            target=self._new_validate(actor,action,target_index)
        else:
            if type(target_index) is not int or target_index not in enemies:
                raise GameError('เลือกเป้าหมายที่ยังมีชีวิตอยู่จากทีมตรงข้าม')
            target=self.fighters[target_index]
        if shot_targets is not None:
            if actor.unit!='mami' or action!='barrage' or not isinstance(shot_targets,list) or not 1<=len(shot_targets)<=3 or any(type(i) is not int or i not in enemies for i in shot_targets):
                raise GameError('เลือกเป้าหมายชุดยิง 1–3 ช่องของฝ่ายตรงข้ามที่ยังมีชีวิต')
        if action=='ultimate':
            if actor.unit not in ULTIMATES:raise GameError('ตัวละครนี้ยังไม่มีอันติ')
            if actor.unit=='aha':
                if self.aha[uid]['wishpower']<self.aha_config['wishpower_cost']:raise GameError('Wishpower ไม่พอ ต้องใช้ 4')
            elif actor.energy<100:raise GameError('เกจอันติยังไม่เต็ม ต้องใช้พลัง 100')
        paid_skill=action in ('skill','prepare','barrage')
        if paid_skill and actor.cooldown:
            raise GameError(f'สกิลรออีก {actor.cooldown} เทิร์นของคุณ')
        if paid_skill and self.sp[uid]<skill_cost(actor.unit):
            raise GameError('SP ไม่พอ ต้องใช้ 1 SP')
        if action=='surrender':
            self.finished=True
            self.winner=next(owner for owner in self.owners if owner!=uid)
            return 'ยอมแพ้ทั้งทีม'
        self.last_action=action
        actor.guard=False
        actor.cooldown=max(0,actor.cooldown-1)
        if actor.state.get('zayin_cd',0):actor.state['zayin_cd']-=1
        special=self._aha_action(actor,target,action) if actor.unit=='aha' else self._new_action(actor,target,action,shot_targets)
        if special is not None:
            if paid_skill:
                self.sp[uid]-=1
                actor.cooldown=skill_cooldown(actor.unit)
            if actor.state.pop('aha_refund',False):self.sp[uid]=min(5,self.sp[uid]+1)
            if action=='ultimate' and actor.unit!='aha':actor.energy-=100
            elif action=='attack':
                self.sp[uid]=min(5,self.sp[uid]+1)
                self._after_normal_attack(actor,target)
            if actor.unit in ULTIMATES and actor.unit!='aha' and action!='ultimate':
                actor.energy=min(100,actor.energy+(25 if action=='attack' else 35))
            self.rounds+=1
            if not self._outcome():
                notes=self._advance()
                if notes:special+='\n'+notes
            return special
        if action=='guard':
            actor.guard=True
            text='ตั้งรับ ลดความเสียหายครั้งถัดไป 50% ไม่คืน SP'
        else:
            if action=='ultimate':
                config=ULTIMATES[actor.unit]
                damage=max(1,actor.max_hp*config['hp_percent']//100) if 'hp_percent' in config else actor.attack*config['attack_multiplier']
                actor.energy-=100
            elif actor.unit=='kuru':
                damage=max(1,actor.max_hp*(32 if action=='skill' else 16)//100)
            else:
                damage=actor.attack*(2 if action=='skill' else 1)
            if actor.unit=='eiji' and action in ('skill','ultimate'):
                damage+=actor.recorded if action=='ultimate' else actor.recorded//2
                actor.recorded=0
            damage=self._strike(actor,target,damage)
            if action=='skill':
                actor.cooldown=skill_cooldown(actor.unit)
                self.sp[uid]-=skill_cost(actor.unit)
                if actor.unit=='kuru' and target.hp>0:target.stunned=1
            elif action=='attack':
                self.sp[uid]=min(5,self.sp[uid]+1)
                self._after_normal_attack(actor,target)
            label=f'🌘 อันติ {ULTIMATES[actor.unit]["name"]}' if action=='ultimate' else 'ใช้สกิล' if action=='skill' else 'โจมตี'
            text=f'{label} ใส่ {CATALOG[target.unit][0]} ทำความเสียหาย {damage}'
            if actor.unit=='yuko' and action in ('skill','ultimate') and target.hp>0:
                target.bleed=3 if action=='ultimate' else 2
                target.bleed_damage=max(1,target.max_hp*8//100)
                text+=' 🌺 แผลฮิกังบาน'
            if actor.unit=='mala' and action in ('skill','ultimate'):
                healed=self._heal(actor,18 if action=='ultimate' else 12,allies=action=='ultimate')
                text+=f' 🎵 ฟื้นฟูทีม {healed} HP'
        if actor.unit in ULTIMATES and actor.unit!='aha' and action!='ultimate':
            actor.energy=min(100,actor.energy+{'attack':25,'skill':35,'guard':15}[action])
        self.rounds+=1
        if not self._outcome():
            notes=self._advance()
            if notes:text+='\n'+notes
        if self.finished and self.winner is None:text+=f' • ครบ {self.limit} เทิร์น เสมอ'
        return text

class TeamBattle(Battle):
    def __init__(self,first,second,store,rng=random):
        self._initialize(first,second,[store.lineup(uid) for uid in (first,second)],rng)
        self._aha_apply_settings(store)
